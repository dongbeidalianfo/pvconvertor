#
# NOTE: INSTALL_PATH is the name of installation;
#

export PVCONVERTOR_HOME=<INSTALL_PATH>
export PATH=$PVCONVERTOR_HOME/bin:$PATH

