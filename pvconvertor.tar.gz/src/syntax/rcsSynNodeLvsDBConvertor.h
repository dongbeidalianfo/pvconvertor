#ifndef SRC_SYNTAX_RCSSYNNODELVSDBCONVERTOR_H_
#define SRC_SYNTAX_RCSSYNNODELVSDBCONVERTOR_H_
#include "public/synnode/rcsSynNodeVisitor.h"
#include "public/token/rcsToken.h"
class rcsSynRuleCheckNode_T;
class rcsSynNode_T;
class rcsSynNodeLvsDBConvertor : public rcsNodeVisitor_T
{
public:
    rcsSynNodeLvsDBConvertor();
    virtual void beginVisitSpecificationNode(rcsSynSpecificationNode_T *pNode);

private:
    bool isPossibleNoParaKeyword(rcsSynSpecificationNode_T *pNode);
    bool getStringName(std::list<rcsToken_T>::iterator &iter,
                       std::list<rcsToken_T>::iterator end,
                       std::string &sValue);
};

#endif
