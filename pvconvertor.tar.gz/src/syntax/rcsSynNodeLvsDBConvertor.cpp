#include "public/manager/rcErrorManager.h"
#include "public/synnode/rcsSynProcNode.h"
#include "public/synnode/rcsSynSpecificationNode.h"
#include "public/manager/rcsManager.h"
#include "rcsSynNodeLvsDBConvertor.h"
#include <fstream>

rcsSynNodeLvsDBConvertor::rcsSynNodeLvsDBConvertor()
{
}

bool rcsSynNodeLvsDBConvertor::isPossibleNoParaKeyword(rcsSynSpecificationNode_T *pNode)
{
    switch(pNode->getSpecificationType())
    {
        case SOURCE_PRIMARY:
        case PEX_REDUCE_RONLY:
        case NON_SUPPORT_SPECIFICATION:
        case PEX_CMD:
            return true;
        default:
            return false;
    }
}

void rcsSynNodeLvsDBConvertor::beginVisitSpecificationNode(rcsSynSpecificationNode_T *pNode)
{
    std::list<rcsToken_T>::iterator iter = pNode->begin();
    ++iter;
    if(!isPossibleNoParaKeyword(pNode) && iter == pNode->end())
    {
        --iter;
        throw rcErrorNode_T(rcErrorNode_T::ERROR, SPC2,
                            pNode->getNodeBeginLineNo(), iter->sValue);
    }

    switch(pNode->getSpecificationType())
    {
        case LVS_DB_LAYER:
        {
            std::list<rcsToken_T>::iterator iter = pNode->begin();
            ++iter;
            while (iter != pNode->end())
            {
                std::string sValue;
                if (getStringName(iter, pNode->end(), sValue))
                {
                    rcsManager_T::getInstance()->getLvsDbLayers().push_back(sValue);
                }
                else
                {
                    throw rcErrorNode_T(rcErrorNode_T::ERROR, INP1,
                                        iter->nLineNo, iter->sValue);
                }
                ++iter;
            }
        }
            break;
        case LVS_DB_CONNECTIVITY_LAYER:
        {
            std::list<rcsToken_T>::iterator iter = pNode->begin();
            ++iter;
            while (iter != pNode->end())
            {
                std::string sValue;
                if (getStringName(iter, pNode->end(), sValue))
                {
                    rcsManager_T::getInstance()->getLvsDbConnectLayers().push_back(sValue);
                }
                else
                {
                    throw rcErrorNode_T(rcErrorNode_T::ERROR, INP1,
                                        iter->nLineNo, iter->sValue);
                }
                ++iter;
            }
        }
            break;
        default:
            break;
    }
}

static std::string
parseTokenString(const rcsToken_T &token)
{
    const std::string &src = token.sValue;
    std::string res;
    std::string::size_type pos = 0;
    if (token.eType == STRING_CONSTANTS)
    {
        while(pos < src.length())
        {
            switch(src[pos])
            {
                case '\t':
                    res += "\\t";
                    break;
                case '\n':
                    res += "\\n";
                    break;
                case '\r':
                    res += "\\r";
                    break;
                case '\a':
                    res += "\\a";
                    break;
                case '\b':
                    res += "\\b";
                    break;
                case '\e':
                    res += "\\e";
                    break;
                case '\f':
                    res += "\\f";
                    break;
                case '\v':
                    res += "\\v";
                    break;
                case '\'':
                    res += "\\\'";
                    break;
                case '\"':
                    res += "\\\"";
                    break;
                case '\\':
                    res += "\\\\";
                    break;
                case '\1':
                    res += "\\1";
                    break;
                case '\2':
                    res += "\\2";
                    break;
                case '\3':
                    res += "\\3";
                    break;
                case '\4':
                    res += "\\4";
                    break;
                case '\5':
                    res += "\\5";
                    break;
                case '\6':
                    res += "\\6";
                    break;
                case '\0':
                    res += "\\0";
                    break;
                default:
                    res += src[pos];
                    break;
            }
            ++pos;
        }
    }
    else
    {
        while(pos < src.length())
        {
            switch(src[pos])
            {
                case '\\':
                    res += "\\\\";
                    break;
                default:
                    res += src[pos];
                    break;
            }
            ++pos;
        }
    }
    return res;
}

#define PVRS_KEYWORD_COUNT 873

static const
char* rcsPvrsKeyword[] =
{
    "LAYOUT_INPUT",
    "LAYOUT_INPUT2",
    "LAYOUT_OA_OPTION",
    "FORMAT",
    "PATH",
    "TOP_CELL",
    "VIEW",
    "PREC",
    "ELLIPSE_SEGMENTS",
    "DONUT_SEGMENTS",
    "PRECISION",
    "RESOLUTION",
    "DB",
    "DRC_RESULT",
    "ERC_RESULT",
    "LIBNAME",
    "TEXT_FORMAT",
    "WITH_PREFIX",
    "WITH_APPEND",
    "MERGED",
    "KEEP_INJECTED_CELL",
    "USER_CELL",
    "DRC_SUMMARY",
    "ERC_SUMMARY",
    "REWRITE",
    "OVERWRITE",
    "APPEND",
    "BY_CELL",
    "DRC_MAX_RESULT",
    "DRC_MAX_VERTEX",
    "ERC_MAX_RESULT",
    "ERC_MAX_VERTEX",
    "ALL",
    "LVS_REPORT",
    "MAX",
    "UNIT",
    "ONLY_WARNING_HCELL",
    "ONLY_WARNING_TOP",
    "OPTION",
    "NOT_SET",
    "NONE",
    "CONNECTION",
    "CONNECTION_EXCLUDE_PG",
    "SHORT_OPEN",
    "SHORT_OPEN_EXCLUDE_PG",
    "MISSING_NET",
    "MISSING_NET_EXCLUDE_PG",
    "MISSING_INSTANCE",
    "MISSING_PROPERTY",
    "MISSING_PROPERTY_TOLERANCE",
    "MERGE_MOS",
    "DETAIL_INFORMATION",
    "PROPERTY",
    "MISSING_CELL",
    "ISOLATED_NET",
    "LAYOUT_PASSTHROUGH",
    "COUNT_BY_MODEL",
    "MISSING_NAME",
    "HCELL",
    "RESOLUTION_WARNING",
    "SHORT_PORT",
    "HCELL_PG",
    "AMBIGUITY",
    "AMBIGUITY_ALL",
    "SHOW_UNICONNECT",
    "SCHEMATIC_PASSTHROUGH_WARNING",
    "SCHEMATIC_PASSTHROUGH",
    "SAME_DATA",
    "SHOW_VIRTUAL_CONNECTION",
    "NOT_IDENTICAL_PIN",
    "PIN_BY_NET",
    "PIN_BY_SHAPE",
    "RC_MODEL",
    "RC_ELEMENT",
    "TEXT_MODEL",
    "TEXT_PROPERTY",
    "DRC_OUTPUT_CELL_NAME",
    "ERC_OUTPUT_CELL_NAME",
    "CELL_COORD",
    "TRAN_TO_TOP",
    "DRC_PROCESS_CELL_TEXT",
    "OUTPUT_NET",
    "TEXT_FORMAT",
    "DRC_RULE_MAP",
    "TEXT_FORMAT",
    "WITH_PREFIX",
    "WITH_APPEND",
    "MAX_RESULT",
    "MAX_VERTEX",
    "ADD_TEXT",
    "DB_PRECISION",
    "DB_MAGNIFY",
    "INJECT_ARRAY",
    "WITH_POLYGON",
    "BY_POLYGON",
    "AUTO_INJECT_ARRAY",
    "DRC_OUTPUT_RULE_TEXT",
    "ERC_OUTPUT_RULE_TEXT",
    "COMMENT",
    "INCREMENTAL_CONNECT_WARNING",
    "DRC_PROGRESSIVE_CONNECT_WARNING",
    "INCREMENTAL_CONNECT",
    "DRC_OUTPUT_REDUCE_FALSE_ERROR",
    "DRC_PROGRESSIVE_CONNECT",
    "DRC_OUTPUT_EMPTY_RULE",
    "DRC_OUTPUT_EMPTY",
    "ERC_OUTPUT_EMPTY_RULE",
    "ERC_OUTPUT_EMPTY",
    "LVS_CHECK_TOP_CELL_PORT",
    "DEVICE_PUSH",
    "PUSH_DEVICE",
    "LVS_SHORT_EQUIVALENT_NET",
    "LVS_SUBCELL_POWER_GROUND",
    "LVS_MATCH_STRICT_SUBTYPE",
    "LVS_KEEP_FLOATING_TOP_NET",
    "LVS_KEEP_PCELL",
    "LVS_PRECISE_OVERLAP",
    "LAYOUT_USE_DB_PRECISION",
    "LVS_IGNORE_EXTRA_PIN",
    "LVS_MATCH_ACCURATE_SUBTYPE",
    "LVS_RUN_ERC",
    "LVS_GLOBAL_NET_AS_PORT",
    "LVS_INJECT_HIERARCHY",
    "LVS_OUTPUT_DEVICE_PROMOTION",
    "LVS_IGNORE_SUBSTRATE_PIN",
    "SNAP_OFFGRID",
    "GUI_PRIORITY",
    "LVS_ZERO_PROPERTY_WITH_TOL",
    "LVS_IGNORE_DEVICE_MODEL",
    "FPD_TOUCH_IN_CELL",
    "LVS_OUTPUT_DEVICE_PROMOTION_MAX",
    "UNICONNECT_CHECK_MAX_RESULT",
    "LVS_POWER",
    "LVS_GROUND",
    "LVS_NON_USER_DEFINE_NAME",
    "INSTANCE",
    "PORT",
    "LVS_KEEP_BLACK_BOX",
    "CELL",
    "DRC_MAGNIFY_RESULT",
    "NAR",
    "SIMULATE_CELL",
    "NEW_CELL",
    "PRINT_LOG",
    "COMPILE",
    "TEXT_MAX",
    "ACUTE",
    "ANGLED",
    "ACUTE_EDGE",
    "ANGLED_EDGE",
    "SELF_INTERSECTING_POLYGON",
    "SELF_INTERSECTING_PATH",
    "OFFGRID_VERTEX",
    "SKEW",
    "SKEW_EDGE",
    "MAX_WARNINGS",
    "CASE_SENSITIVE",
    "LAYOUT",
    "COMPARE",
    "SCHEMATIC",
    "LOWER_DEVICE_CASE",
    "LAYOUT_PROPERTY_NET",
    "LAYOUT_PROPERTY",
    "LAYOUT_NET",
    "NAME",
    "TYPE",
    "SUBTYPE",
    "STR_VALUE",
    "CHECK_PROPERTY",
    "ABSOLUTE_VALUE",
    "STRING",
    "NOT_STRING",
    "CELL_GROUP",
    "DEVICE_MERGE",
    "PARALLEL_BJT",
    "SPLIT",
    "SPLIT_GATE",
    "USER_DEFINE",
    "PARALLEL_CAP",
    "PARALLEL_DIO",
    "PARALLEL_MOS",
    "PARALLEL_RES",
    "SERIES_CAP",
    "SERIES_MOS",
    "SERIES_RES",
    "PARTIAL_SERIES_MOS",
    "PARTIAL",
    "IN_ORDER",
    "IN_TOLERANCE",
    "DIFFERENT_TYPE",
    "SERIES_PARALLEL",
    "PARALLEL",
    "SERIES",
    "CELL_GROUP",
    "DRC_IGNORE_RULE",
    "DFM_IGNORE_RULE",
    "BY_NAME",
    "BY_LAYER",
    "DRC_SELECT_RULE",
    "DFM_SELECT_RULE",
    "ERC_IGNORE_RULE",
    "ERC_SELECT_RULE",
    "QUIT_LVS",
    "DRC_TOLERANCE",
    "DISTANCE",
    "GROUP_RULE",
    "HCELL",
    "LABEL_LEVEL",
    "PORT",
    "TEXT",
    "LABEL_LAYER",
    "PORT_POLYGON",
    "LAYER_MAP",
    "LAYOUT_ADD_CELL",
    "LVS_DB",
    "LVS_OUTPUT_NETLIST",
    "SCHEMATIC",
    "INJECTED_LAYOUT",
    "INJECTED_SCHEMATIC",
    "SCHEMATIC_INPUT",
    "FORMAT",
    "PATH",
    "VAR",
    "LVS_CELL_GROUP",
    "ADD_POLYGON",
    "ADD_TEXT",
    "LAYOUT_ADD_POLYGON",
    "LAYOUT_ADD_TEXT",
    "DEVICE_FILTER",
    "SHORT",
    "OPEN",
    "SCHEMATIC",
    "DEVICE_FILTER_UNUSED",
    "BJT",
    "CAP",
    "DIO",
    "MOS",
    "RES",
    "DEVICE_FILTER_OPTION",
    "CONNECTED_GSD",
    "FLOATING_G_POWER_SD",
    "FLOATING_G_GROUND_SD",
    "FLOATING_GSD",
    "CONNECTED_SD",
    "CONNECTED_ALL",
    "NOPATH_G_FLOATING_SORD",
    "NOPATH_G_FLOATING_S_OR_D",
    "SUPPLY_G_FLOATING_SORD",
    "POWER_GROUND_G_FLOATING_S_OR_D",
    "FLOATING_G_GROUNDPATH_SD",
    "FLOATING_G_GROUND_PATH_SD",
    "FLOATING_G_POWERPATH_SORD",
    "FLOATING_G_POWER_PATH_S_OR_D",
    "GROUND_NGATE",
    "GROUND_NGATE2",
    "POWER_PGATE",
    "POWER_PGATE2",
    "ONLYPOWER_SD",
    "ONLY_POWER_SD",
    "ONLYGROUND_SD",
    "ONLY_GROUND_SD",
    "POWERGROUND_SD",
    "POWER_GROUND_SD",
    "SUPPLY_G_CONNECTED_SD",
    "POWER_GROUND_G_CONNECTED_SD",
    "NOPATH_SD",
    "ONLYFLOATING_SORD",
    "ONLY_FLOATING_S_OR_D",
    "GROUND_PGATE2",
    "POWER_NGATE2",
    "FILTERALL",
    "FILTER_ALL",
    "REPEAT_FILTER_ALL",
    "NOPATH_DEVICE",
    "SUPPLY_DEVICE",
    "POWER_GROUND_DEVICE",
    "FLOATING_R",
    "CONNECTED_R",
    "FLOATING_C",
    "CONNECTED_C",
    "FLOATING_D",
    "CONNECTED_D",
    "FLOATING_Q",
    "CONNECTED_EC",
    "FLOATING_SD",
    "FLOATING_MOS",
    "CONNECTED_BE",
    "CONNECTED_Q",
    "FLOATINGALL_R",
    "FLOATINGALL_C",
    "FLOATINGALL_D",
    "FLOATINGALL_Q",
    "FLOATING_R_ALL",
    "FLOATING_C_ALL",
    "FLOATING_D_ALL",
    "FLOATING_Q_ALL",
    "DEVICE_MAP",
    "DEVICE_MERGE_PRIORITY",
    "DEVICE_PIN_SWAP",
    "CAP",
    "MOS_RES",
    "DEVICE_PROPERTY",
    "MAP",
    "INIT",
    "LVS_CHECK_PROPERTY_RADIUS",
    "DEVICE_TYPE_MAP",
    "ERC_FIND_SHORT",
    "ERC_MAX_SHORTS",
    "ERC_FIND_SHORTS_IGNORE_NETS",
    "BY_CELL_ALSO",
    "BY_LAYER_ALSO",
    "ALL_CELL",
    "IGNORE_CONTACT",
    "KEEP_UNMERGED",
    "HOT_SPOT",
    "FLAT",
    "AMONG_NET",
    "AMONG_NAME",
    "IGNORE_NET",
    "ERC_FIND_OPEN",
    "ERC_FIND_OPEN_NETS",
    "ERC_FIND_OPEN_IGNORE_NETS",
    "ERC_MAX_OPENS",
    "ERC_MAX_NETS_PER_OPEN",
    "IGNORE_CONTACT",
    "MAX_NETS_PER_OPEN",
    "FPD_SHOT_ANALYSIS",
    "GLASS_CELL",
    "MASK_GDS",
    "MASK_LAYER",
    "MASK_PITCH",
    "MASK_ROW_COL",
    "FIRST_MASK_CENTER_IN_GLASS",
    "MASK_CELL_INFO",
    "MASK_CELL",
    "MARK_FILTER_FILE",
    "ERC_PATH_CHECK",
    "PATH_CHECK",
    "OUTPUT_POLYGON",
    "OUTPUT_NET",
    "WITH_PORT",
    "IGNORE_FLOATING",
    "IGNORE_FLOATTING",
    "ONLY_USED",
    "EXCLUDE_POWER_GROUND",
    "POWERED",
    "GROUNDED",
    "LABELED",
    "POWER",
    "GROUND",
    "LABEL",
    "STOP",
    "ERC_PATH_DEVICE",
    "CELL",
    "IN_CELL",
    "HEAD_NAME",
    "IGNORE_ORIGINAL_LAYER_CHECK",
    "ACUTE_EDGE",
    "ANGLED_EDGE",
    "OFFGRID_VERTEX",
    "SKEW_EDGE",
    "LAYER_DIR",
    "LAYOUT_CONNECT_LAYER",
    "LAYOUT_DEVICE_CELL",
    "LAYOUT_DEVICE_LAYER",
    "LAYOUT_READ_LEVEL",
    "LAYOUT_READ",
    "DUPLICATE_CELL",
    "BOX_RECORD",
    "NODE_RECORD",
    "LVS_BLACK_BOX",
    "IND",
    "LEN",
    "RES",
    "TIME",
    "VIRTUAL_CONNECT",
    "BLACK_BOX_COLON",
    "BLACK_BOX_NAME",
    "COLON",
    "LEVEL",
    "PROGRESSIVE_CONNECT",
    "INCREMENTAL_CONNECT",
    "NAME",
    "REPORT_WARNING",
    "REPORT_MAX",
    "SEMICOLON",
    "UNICONNECT",
    "FLOATING_POLYGON_NAME",
    "ADJACENT",
    "WITH",
    "QUIT",
    "LAYOUT_ERROR",
    "ERC_ERROR",
    "UNICONNECT_CHECK",
    "POWER_GROUND_ERROR",
    "COMPILE_ERROR",
    "PUSH_CELL_LOWEST",
    "SPICE",
    "XSCALE",
    "SWAP_WL",
    "STRICT_WIDTH_LENGTH",
    "STRICT_WL",
    "TREAT_SLASH_AS_SPACE",
    "SPLIT_MULTIPLER_DEVICE",
    "RENAME_PARAM",
    "REDEFINE_PARAM_VALUE",
    "USE_SUBCELL_PIN",
    "REWRITE_GLOBAL_NET",
    "MULTIPLIER_FACTOR_NAME",
    "CALCULATE_MOS_AREA",
    "IGNORE_PRIMITIVE_SUBCIRCUIT",
    "CONDITIONAL_COMMENT_LDD",
    "PERMIT_UNQUOTED_STRING",
    "PERMIT_INLINE_PARAMETER",
    "PERMIT_DUPLICATE_SUBCIRCUIT",
    "PERMIT_FLOATING_PIN",
    "SWAP_WL",
    "STRICT_WIDTH_LENGTH",
    "STRICT_WL",
    "TREAT_SLASH_AS_SPACE",
    "SPLIT_MULTIPLER_DEVICE",
    "RENAME_PARAM",
    "REDEFINE_PARAM_VALUE",
    "USE_SUBCELL_PIN",
    "REWRITE_GLOBAL_NET",
    "MULTIPLIER_FACTOR_NAME",
    "CALCULATE_MOS_AREA",
    "IGNORE_PRIMITIVE_SUBCIRCUIT",
    "CONDITIONAL_COMMENT_LDD",
    "PERMIT_UNQUOTED_STRING",
    "PERMIT_INLINE_PARAMETER",
    "PERMIT_DUPLICATE_SUBCIRCUIT",
    "PERMIT_FLOATING_PIN",
    "FLOATING_PIN",
    "DUPLICATE_NAME",
    "KEEP_NAME",
    "FLOATING_PIN",
    "DUPLICATE_NAME",
    "KEEP_NAME",
    "JFET",
    "IND",
    "X_INSTANCE",
    "VOLTAGE",
    "SBUCKT",
    "PARAM",
    "LEFT_SIDE",
    "RIGHT_SIDE",
    "COMMENT_CODED",
    "LVS_IDENTIFY_GATE",
    "BASIC",
    "DIFFERENT_SUBTYPE",
    "DIFF_SUBTYPE",
    "X_SUBTYPE",
    "IN_TOLERANCE",
    "CELL_GROUP",
    "DRC_WAIVE_ERROR",
    "NETLIST",
    "EXTRACT_ALL_TEXTED_PIN",
    "EXTRACT_INCONSISTENT_MODEL",
    "EXTRACT_BLACK_BOX_CONTENT",
    "PROPERTY_IN_COMMENT",
    "SUBSTRATE_IN_COMMENT",
    "UNNAMED_BLACK_BOX_PIN",
    "EXTRACT_PIN_LOCATION",
    "PROMOTE_CELL",
    "PROMOTE_CELL_TEXT",
    "LAYOUT_CELL_GROUP",
    "WITH_TEXT",
    "LAYOUT_REMOVE_TEXT",
    "LAYOUT_RENAME_TEXT",
    "CELL_GROUP",
    "IN_DB",
    "IN_RULE",
    "IN_LAYER",
    "LAYOUT_EXCEPTION",
    "SEVERITY",
    "RESULT_DB",
    "SORT_BY_CELL",
    "SORT_BY_LAYER",
    "SORT_BY_EXCEPTION",
    "IN_TOP",
    "IN_CELL",
    "MAG_DB",
    "BOX_RECORD",
    "NSTRING_CELL_NAME",
    "NODE_RECORD",
    "NSTRING_PROPNAME",
    "ASTRING_TEXTSTRING",
    "XELEMENT",
    "XNAME",
    "LAYOUT_ADD_TEXT",
    "TEXT_LARGE",
    "TEXT_DEFECTIVE",
    "METRIC_LAYOUT",
    "METRIC_RULE_DECK",
    "PRECISION_LAYOUT",
    "PRECISION_CONFLICT",
    "PRECISION_RULE_DECK",
    "PRECISION_DB",
    "LAYOUT_RESERVE_CELL_GROUP",
    "LAYOUT_RENAME_CELL",
    "LAYOUT_EXCLUDE_WINDOW",
    "REGION",
    "ORIGINAL_LAYER",
    "USED_LAYER",
    "LAYOUT_SELECT_WINDOW",
    "CLIP",
    "ORIGINAL",
    "USED",
    "ORIGINAL_LAYER",
    "USED_LAYER",
    "LVS_CORRESPONDING_NET",
    "LVS_IGNORE_HCELL",
    "LVS_EXPAND_HCELL",
    "PROMOTION",
    "DEVICE_PROMOTION",
    "UNBALANCE",
    "LVS_LAYOUT_GLOBAL_NET_GROUP",
    "LVS_TEMP_DIR",
    "LVS_IGNORE_PORT",
    "SUBCELL",
    "UNICONNECT_CHECK",
    "LOWER_LAYER",
    "VIA_LAYER",
    "UPPER_LAYER",
    "ALL_LAYER",
    "LAYOUT_MAGNIFY",
    "NEW_CELL",
    "DEFAULT",
    "GEOM_AND",
    "GEOM_OR",
    "GEOM_XOR",
    "GEOM_NOT",
    "EDGE_OR",
    "SAME_NET",
    "DIFF_NET",
    "GEOM_CUT",
    "~GEOM_CUT",
    "GEOM_INSIDE",
    "~GEOM_INSIDE",
    "GEOM_OUTSIDE",
    "~GEOM_OUTSIDE",
    "GEOM_INTERACT",
    "~GEOM_INTERACT",
    "GEOM_ADJACENT",
    "~GEOM_ADJACENT",
    "GEOM_ENCLOSE",
    "~GEOM_ENCLOSE",
    "COUNT_BY_NET",
    "POINT_TOUCH",
    "ONLY_POINT_TOUCH",
    "ATTACH_ORDER",
    "WITH",
    "GEOM_AREA",
    "~GEOM_AREA",
    "GEOM_DONUT",
    "~GEOM_DONUT",
    "GEOM_PERIMETER",
    "GEOM_VERTEX",
    "GEOM_FLATTEN",
    "GEOM_WITH_WIDTH",
    "~GEOM_WITH_WIDTH",
    "GEOM_WITH_EDGE",
    "~GEOM_WITH_EDGE",
    "EDGE_ANGLE",
    "~EDGE_ANGLE",
    "EDGE_LENGTH",
    "~EDGE_LENGTH",
    "EDGE_PATH_LENGTH",
    "EDGE_ADJACENT",
    "~EDGE_ADJACENT",
    "INSIDE",
    "OUTSIDE",
    "BOTH_SIDE",
    "INSIDE",
    "OUTSIDE",
    "BOTH_SIDE",
    "POINT",
    "ONLY_POINT",
    "EDGE_INSIDE",
    "~EDGE_INSIDE",
    "EDGE_OUTSIDE",
    "~EDGE_OUTSIDE",
    "EDGE_",
    "~EDGE_",
    "INSIDE",
    "OUTSIDE",
    "BOTH_SIDE",
    "INSIDE",
    "OUTSIDE",
    "BOTH_SIDE",
    "GEOM_RECTANGLE",
    "~GEOM_RECTANGLE",
    "RATIO",
    "ORTHOGONAL",
    "ONLY_ORTHOGONAL",
    "BY_BOUNDARIES",
    "EDGE_CONVEX_POINT",
    "LENGTH",
    "WITH_EDGE_LENGTH",
    "ADJACENT_EDGE_ANGLE1",
    "ADJACENT_EDGE_LENGTH1",
    "ADJACENT_EDGE_ANGLE2",
    "ADJACENT_EDGE_LENGTH2",
    "GEOM_ORTHOGONALIZE_ANGLE",
    "BY_SKEW_EDGE",
    "ONLY_BY_ORTHOGONAL",
    "ALL_EDGE",
    "CHECK_ORIGINAL_LAYER",
    "ACUTE_EDGE",
    "ANGLED_EDGE",
    "OFFGRID_VERTEX",
    "SKEW_EDGE",
    "IGNORE_ACUTE_EDGE",
    "IGNORE_ANGLED_EDGE",
    "IGNORE_OFFGRID_VERTEX",
    "IGNORE_SKEW_EDGE",
    "GEOM_HOLES",
    "INNER_MOST",
    "HOLLOW",
    "GEOM_SIZE",
    "FPD_SIZE",
    "DFM_GEOM_SIZE",
    "OUTPUT_OVERLAP_REGION",
    "ZOOM_OUT_IN",
    "ZOOM_IN_OUT",
    "OUT_IN",
    "IN_OUT",
    "INSIDE_OF_LAYER",
    "OUTSIDE_OF_LAYER",
    "CLIP",
    "CLIP_CORNER",
    "GEOM_INSIDE_CELL",
    "~GEOM_INSIDE_CELL",
    "PATTERN_MATCH",
    "WITH_LAYER",
    "GEOM_NET",
    "~GEOM_NET",
    "BY_AREA",
    "GEOM_ENCLOSE_RECTANGLE",
    "~GEOM_ENCLOSE_RECTANGLE",
    "ORTHOGONAL",
    "GEOM_GET_BOUNDARY",
    "GEOM_GET_BOUNDARIES",
    "OUTPUT_CENTER",
    "OUTPUT_SQUARE",
    "INSIDE_OF_LAYER",
    "SPACE",
    "WIDTH",
    "OVERLAP",
    "EXTENSION",
    "REDUCE_FALSE",
    "SAME_POLYGON",
    "DIFF_POLYGON",
    "NO_SHIELDED_EDGE",
    "COIN_EDGE_ALSO",
    "ACUTE_ALSO",
    "ACUTE_ONLY",
    "NOT_ACUTE",
    "PARA_ALSO",
    "PARA_ONLY",
    "NOT_PARA",
    "PERP_ALSO",
    "PERP_ONLY",
    "NOT_PERP",
    "OBTUSE_ALSO",
    "OBTUSE_ONLY",
    "NOT_OBTUSE",
    "APPOSITION",
    "NO_APPOSITION",
    "ANGLED_EDGE",
    "CORNER_CORNER",
    "CORNER_EDGE",
    "ALL_CORNER",
    "NOT_CORNER",
    "INTERSECTING_ONLY",
    "ADJACENT",
    "OVERLAPPED",
    "POINT_TOUCH",
    "INSIDE_ALSO",
    "OUTSIDE_ALSO",
    "REGION_BOUNDARIES",
    "REGION_CENTERLINE",
    "SHIELDED_LEVEL",
    "CHECK_DENSITY",
    "BY_WINDOW",
    "DELTA",
    "BOUNDARY_TRUNCATE",
    "BOUNDARY_BACKUP",
    "BOUNDARY_IGNORE",
    "BOUNDARY_REPEAT",
    "INSIDE_OF_BOUNDARY",
    "INSIDE_OF_REGION",
    "INSIDE_OF_LAYER",
    "IN_BOUNDARY",
    "IN_BOUNDARIES",
    "IN_POLYGON",
    "IN_RECTANGLE",
    "IN_BOUNDARIES_CENTER",
    "CHECK_GRADIENT",
    "CHECK_GRADIENT_IN_SEPARATE_WINDOW",
    "CHECK_SEPARATE_GRADIENT",
    "RELATIVE_RATIO",
    "ABSOLUTE_VALUE",
    "OUTPUT_CENTER",
    "OUTPUT_LOG",
    "ONLY_OUTPUT_LOG",
    "RESULT_DB",
    "ONLY_RESULT_DB",
    "MAG",
    "CORNER_ALSO",
    "CHECK_NAR",
    "CHECK_INCREMENTAL_NAR",
    "MAG_BY",
    "COUNT",
    "PERIMETER",
    "DIVIDE",
    "INSIDE_OF_LAYER",
    "INCREMENTAL",
    "RESULT_DB",
    "RESULT_DB_ONLY",
    "ONLY_RESULT_DB",
    "MAG",
    "OUTPUT_BY_LAYER",
    "CHECK_OFFGRID",
    "INSIDE_OF_LAYER",
    "NEW_COORD",
    "ORIGINAL_COORD",
    "RELATIVE_RATIO",
    "ABSOLUTE_VALUE",
    "OUTPUT_CENTER",
    "OUTPUT_EDGE",
    "OUTPUT_REGION",
    "OFFSET_VALUE",
    "INSIDE_VALUE",
    "OUTSIDE_VALUE",
    "WITH_HINT",
    "DEVICE_SEED_LAYER",
    "WITH_PROPERTY",
    "ONLY_USED",
    "ENC_RECT",
    "OUTSIDE_ALSO",
    "ADJACENT",
    "POINT_TOUCH",
    "ONLY_ORTHOGONAL",
    "CORRECT",
    "INCORRECT",
    "GEOM_EDGE_TO_RECT",
    "INSIDE_BY_FACTOR",
    "OUTSIDE_BY_FACTOR",
    "BOTH_SIDE",
    "BOTH_SIDE_BY_FACTOR",
    "EXTEND",
    "EXTEND_BY_FACTOR",
    "FILL_CORNER",
    "GEOM_FILL_RECTANGLES",
    "INSIDE_OF_LAYER",
    "INSIDE_OF_REGION",
    "DELTA",
    "KEEP_SPACING",
    "GEOM_GET_CELL_BOUNDARY",
    "ORIGINAL_LAYER",
    "MAPPED_LAYER",
    "USED_LAYER",
    "PATTERN_MATCH",
    "GEOM_GET_LAYOUT_BOUNDARY",
    "ORIGINAL_LAYER",
    "IGNORE_LAYER",
    "GEOM_MAGNIFY",
    "GEOM_MERGE",
    "GEOM_ROTATE",
    "GEOM_SHIFT",
    "GEOM_SNAP",
    "GEOM_OR_NET",
    "KEEP_SHAPE",
    "GEOM_ORTH_SIZE",
    "IN_ORDER",
    "GEOM_PUSH",
    "WITH_LAYER",
    "LEVEL",
    "GEOM_TEXT_TO_RECT",
    "BY_LEVEL",
    "TOP_CELL",
    "KEEP_CASE",
    "GEOM_TRANSFER_NETID",
    "INCLUDE_ADJACENT",
    "GEOM_WITH_ADJACENT",
    "~GEOM_WITH_ADJACENT",
    "DISTANCE",
    "SQUARE",
    "FROM_CENTER",
    "OCTAGONAL_RECT",
    "ORTHOGONAL_RECT",
    "INSIDE_OF_LAYER",
    "GEOM_WITH_LABEL",
    "~GEOM_WITH_LABEL",
    "KEEP_CASE",
    "CASE_SENSITIVE",
    "TABLE_DRC",
    "REGION",
    "NO_SHIELDED_EDGE",
    "APPOSITION",
    "CHECK_SPACE",
    "CHECK_WIDTH",
    "WITH_WIDTH1",
    "WITH_WIDTH2",
    "SHIELDED_LEVEL",
    "DFM_CREATE_NAR",
    "BY_PROPERTY",
    "DFM_MERGE_PROPERTY",
    "ADJACENT",
    "MULTI_CLUSTER",
    "SINGLE_CLUSTER",
    "DFM_BUILD_PROPERTY",
    "CLIP",
    "OVERLAPPED",
    "ADJACENT",
    "POINT_TOUCH",
    "MULTI_CLUSTER",
    "SINGLE_CLUSTER",
    "REGION",
    "DFM_RESULT",
    "FIRST_NODE",
    "ALL_NODE",
    "OTHER_NODE",
    "FLATTEN_INJECTION",
    "IGNORE_EMPTY",
    "OUTPUT_BOUNDARY",
    "MAX_RESULT",
    "DFM_COPY",
    "REGION",
    "UNMERGED_REGION",
    "MIDDLE_LINE",
    "CONNECTING_LINE",
    "CONNECTING_MIDPOINT",
    "EDGE_COLLECTION",
    "LAYER_ID",
    "UNMERGED_EDGE",
    "CELL_GROUP",
    "DFM_CHECK_SPACE",
    "DELTA",
    "BY_EXT",
    "BY_INT",
    "BY_ENC",
    "BY_ALL",
    "X_DIRECTION",
    "Y_DIRECTION",
    "SHIELD_LEVEL",
    "SHIELD_LAYER",
    "CHECK_ALL",
    "DFM_TRANSFER_NETID",
    "OPC_BIAS",
    "LIMIT",
    "CONVEX_LIMIT",
    "CONCAVE_LIMIT",
    "SLANT_LIMIT",
    "SLANT_CONVEX_LIMIT",
    "SLANT_CONCAVE_LIMIT",
    "DIAGONAL",
    "WITH_SPACE",
    "WITH_WIDTH1",
    "WITH_WIDTH2",
    "WITH_LENGTH1",
    "WITH_LENGTH2",
    "BIAS",
    "DEVICE_GROUP",
    "TRS_FUNCTION",
    "DEFINE_FUN",
    "CALL_FUN",
    "FPD_PIXEL_CELL",
    "FPD_PANEL_CELL",
    "FPD_MASK_CELL",
    "FPD_MASK_SHOT_CELL",
    "FPD_MASK_GLASS_CELL",
    "REMOVE_CONNECT",
};

static bool
isPvrsKeyword(const std::string &sName)
{
    if(0 == strncasecmp(sName.c_str(), "DRC_", 4) || 0 == strncasecmp(sName.c_str(), "ERC_", 4) ||
       0 == strncasecmp(sName.c_str(), "LAYOUT_", 7) || 0 == strncasecmp(sName.c_str(), "GEOM_", 5) ||
       0 == strncasecmp(sName.c_str(), "~GEOM_", 6) || 0 == strncasecmp(sName.c_str(), "LVS_", 4) ||
       0 == strncasecmp(sName.c_str(), "DFM_", 4) || 0 == strncasecmp(sName.c_str(), "FPD_", 4))
        return true;



    const char *pValue = g_warpper_getenv("PVCONVERTOR_HOME");
    if(NULL != pValue)
    {
        string strPvrsKeyWordCfg(pValue);
        strPvrsKeyWordCfg.append("/pvconvertor/pvrsKeyWord.list");
        std::ifstream fRead;
        fRead.open(strPvrsKeyWordCfg.c_str());
        string strTmp;
        while(getline(fRead,strTmp))
        {
            trim(strTmp);
            if(0 == strcasecmp(sName.c_str(), strTmp.c_str()))
            {
                return true;
            }
        }
        fRead.close();
    }


    for(hvUInt32 index = 0; index < PVRS_KEYWORD_COUNT; ++index)
    {
        const char* prefix = rcsPvrsKeyword[index];
        if(0 == strcasecmp(sName.c_str(), prefix))
        {
            return true;
        }
    }
    return false;
}

bool
rcsSynNodeLvsDBConvertor::getStringName(std::list<rcsToken_T>::iterator &iter,
                                        std::list<rcsToken_T>::iterator end,
                                        std::string &sValue)
{
    if (iter == end)
        return false;

    switch(iter->eType)
    {
        case SECONDARY_KEYWORD:
        case IDENTIFIER_NAME:
        {
            if (!isValidSvrfName(iter->sValue))
            {
                throw rcErrorNode_T(rcErrorNode_T::ERROR, INP1,
                                    iter->nLineNo, iter->sValue);
            }
        }
        case STRING_CONSTANTS:
        {
            sValue = parseTokenString(*iter);
            break;
        }
        case SPECIFICATION_KEYWORD:
            if(strcasecmp(iter->sValue.c_str(), "TRACE PROPERTY") == 0)
            {
                iter++;
                sValue = parseTokenString(*iter);
            }
            break;
        default:
            return false;
    }

    if (iter->eType == STRING_CONSTANTS)
    {
        sValue.insert(0, "\"");
        sValue.insert(sValue.size(), "\"");
    }
    else if (iter->eType != STRING_CONSTANTS)
    {
        bool hasSpecificSymbol = false;
        hvUInt32 iValue = 0;
        while(iValue < sValue.size())
        {
            if(sValue[iValue] == ';' || sValue[iValue] == ' ')
            {
                hasSpecificSymbol = true;
                break;
            }
            ++iValue;
        }

        if(hasSpecificSymbol)
        {
            sValue.insert(0, "\"");
            sValue.insert(sValue.size(), "\"");
        }
        else if(strcasecmp(sValue.c_str(), "RULE") == 0 || isPvrsKeyword(sValue))
        {
            sValue.insert(0, "\"");
            sValue.insert(sValue.size(), "\"");
        }
    }
    if (!iter->namescopes.empty())
    {
        return true;
    }
    return true;
}
