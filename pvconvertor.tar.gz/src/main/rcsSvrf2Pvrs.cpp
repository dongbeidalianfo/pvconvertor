#undef yyFlexLexer
#define yyFlexLexer rcslexFlexLexer

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <iostream>
#include <fstream>
#include <sstream>

#include "public/synnode/rcsSynRootNode.h"
#include "public/manager/rcErrorManager.h"
#include "public/manager/rcsManager.h"
#include "preprocess/rcsPreprocessor.h"
#include "preprocess/rcsCheckTextExtractor.h"
#include "preprocess/rcsFormat.h"
#include "lexical/rcsLexParser.h"
#include "lexical/rcsMacroParser.h"
#include "syntax/rcsSynConvertor.h"
#include "tvf/rcsTvfCompiler.h"
#include "tvf/rcpTrsCompiler.h"
#include "tvf/rcsTvfConvertor.h"
#include "lexical/FlexLexer.h"

#include "rcsSvrf2Pvrs.h"

hvUInt32 rcsSvrf2Pvrs::mCurLineNo = 0;
hvUInt32 rcsSvrf2Pvrs::mStrSearchBegin = 0;
std::string rcsSvrf2Pvrs::mCompleteStr = "";

bool
rcsSvrf2Pvrs::isTVFRule(const char* pFilename, bool* isTVF, bool* isTRS)
{
    FILE* fp = fopen(pFilename, "r");
    if(fp == NULL)
    {
        printf("Error: Can't open file %s\n", pFilename);
        return false;
    }

    char line[1024];
    size_t len = 0;
    bool bTVF = false;
    len = fread(line, 1, 1023, fp);
    line[len]='\0';

    if(len  >  0)
    {
        size_t i = 0;
        while( i<len )
        {
            if(' ' != line[i] && '\t' != line[i] )
            {
                break;
            }
            ++i;
        }
        if( i < len && strncmp( line+i, "#!", 2 ) == 0 )
        {
        	rcsManager_T::getInstance()->setRuleFileHasPrefix(true);
            i += 2; 
            while( i<len )
            {
                if( ' ' != line[i] && '\t' != line[i] )
                {
                    break;
                }
                ++i;
            }
            if(i < len)
            {
            	if(strncasecmp( line + i, "tvf", 3 ) == 0 )
            	{
            		bTVF = true;
            		if(isTVF)
            			*isTVF = true;
            	}
            	else if(strncasecmp( line + i, "trs", 3 ) == 0)
            	{
            		if(isTRS)
            			*isTRS = true;
            	}

            }
        }
        else if( i < len )
        {
        	if(strncasecmp( line+i, "tvf::", 5) == 0 )
        	{
        		bTVF = true;
        		if(isTVF)
        			*isTVF = true;
        	}
        	else if(strncasecmp( line+i, "trs::", 5 ) == 0)
        	{
        		if(isTRS)
        			*isTRS = true;
        	}
        }
    }
    else
    {
        printf("Error: file %s is empty\n", pFilename);
        
        
    }

    fclose(fp);

    return bTVF;
}

rcsSvrf2Pvrs::~rcsSvrf2Pvrs()
{
    remove(rcsManager_T::getInstance()->getTmpFileName());
    remove(".svrf2pvrs.switch.tmp");
}

bool
rcsSvrf2Pvrs::executeForTvfCommand(std::string &script)
{
    try
    {
        static const char *pSvrfGenFromTvf = ".svrfgenformtvf";
        FILE *pFile = fopen(pSvrfGenFromTvf, "w");
        fputs(script.c_str(), pFile);
        fclose(pFile);

        std::ofstream outFile(rcsManager_T::getInstance()->getTmpFileName());
        rcsPreProcessor_T processor(pSvrfGenFromTvf, true, outFile);
        processor.initial();
        processor.execute();
        outFile.flush();
        outFile.close();

        rcsCheckTextExtractor_T extractor(rcsManager_T::getInstance()->getTmpFileName());
        extractor.execute();
        std::list<rcsToken_T> tokens;
        std::set<hvUInt32> vUnstoredCommentLineNumbers;
        rcsLexParser_T lexparser(tokens, vUnstoredCommentLineNumbers);
        lexparser.parse(rcsManager_T::getInstance()->getTmpFileName());
        std::map<hvUInt32, std::pair<hvUInt32, bool> > blankLinesBefore;
        rcsLexMacroParser_T macroparser(tokens, blankLinesBefore, vUnstoredCommentLineNumbers, false, true);
        macroparser.parse();

        bool bIsRunTVF = false;
		if(rcsManager_T::getInstance()->isTrsFlag())
		{
			bIsRunTVF = false;
		}
		else
		{
			bIsRunTVF = true;
		}

        rcsSynConvertor convertor(tokens,bIsRunTVF);
        convertor.setMacroParaMap(&macroparser.m_macrosParaSizeMap);
        rcsSynRootNode_T *pNode = convertor.execute(blankLinesBefore);

        delete pNode;

        remove(rcsManager_T::getInstance()->getTmpFileName());
        remove(pSvrfGenFromTvf);

        hvUInt32 _includeFileSize = processor.getIncludeFileVectorSize();
        for(hvUInt32 _index = 0; _index < _includeFileSize; _index++)
        {
            rcsManager_T::getInstance()->pushIncludeFileName(processor.getIncludeFile(_index));
        }
    }
    catch(const rcErrorNode_T &error)
    {
        s_errManager.addError(error, std::cout);
        return false;
    }
    return true;
}

void
rcsSvrf2Pvrs::processIncludeFileRespectively(rcsPreProcessor_T &preProcessor)
{
    
    if(preProcessor.getIncludeFileVectorSize())
    {
        rcsSvrf2Pvrs convertor;
        std::string switchFile;

        for(hvUInt32 i = 0; i < preProcessor.getIncludeFileVectorSize(); i++)
        {
            convertor.setLastGlobalLine(rcsPreProcessor_T::lastGlobalLine());
        	std::string includeFileName = preProcessor.getIncludeFile(i);
        	size_t it;
        	std::string inputFileName;
        	if((it = includeFileName.find(".trs")) != std::string::npos)
        	{
        		std::string tmp = includeFileName;
        		inputFileName = tmp.erase(it, 4);
        	}
        	else if((it = includeFileName.find(".pvrs")) != std::string::npos)
        	{
        		std::string tmp = includeFileName;
        		inputFileName = tmp.erase(it, 5);
        	}

        	rcsManager_T::getInstance()->setFirstTime(false);

        	convertor.execute(inputFileName, switchFile, includeFileName,
							   rcsManager_T::getInstance()->isSvrfComment(),
							   rcsManager_T::getInstance()->isConvertSwitch(),
							   rcsManager_T::getInstance()->isFlattenMacro(),
							   rcsManager_T::getInstance()->outputComment(),
							   std::cout,
							   rcsManager_T::getInstance()->isNewPvrs(),
							   rcsManager_T::getInstance()->needExpandTmpLayer(),
							   rcsManager_T::getInstance()->isConvertIncludeFile(),
							   rcsManager_T::getInstance()->isTvf2Trs());
        }
    }
}

static std::list<rcsToken_T>::iterator
getOperationNodeEnd(std::list<rcsToken_T>::iterator &iterKeyWord,
                    std::list<rcsToken_T>::iterator &iterCur)
{
    if(iterKeyWord->nLineNo == iterCur->nLineNo)
    {
        return iterCur;
    }
    else
    {
        std::list<rcsToken_T>::iterator iterEnd = iterKeyWord;
        while(iterEnd->nLineNo != iterCur->nLineNo)
        {
            ++iterEnd;
        }
        return iterEnd;
    }
}

static bool
parseSpecification(std::list<rcsToken_T>::iterator &iter, std::list<rcsToken_T> *pTokenStream)
{
    std::list<rcsToken_T>::iterator iterPrimaryKeyWord = iter++;
    std::list<rcsToken_T> &tokenStream = *pTokenStream;
    while(iter != tokenStream.end())
    {
        if(LAYER_OPERATION_KEYWORD == iter->eType)
        {
            std::list<rcsToken_T>::iterator iterEnd = getOperationNodeEnd(iterPrimaryKeyWord, iter);
            iter = iterEnd;
            break;
        }
        else if(SPECIFICATION_KEYWORD == iter->eType || BLANK_KEY == iter->eType ||
                iter->eType == CMACRO || iter->eType == DMACRO || RULE_CHECK == iter->eType)
        {
            break;
        }
        else if(SEPARATOR == iter->eType)
        {
            if(("=" == iter->sValue) || ("{" == iter->sValue))
            {
                --iter;
                break;
            }
            else if("}" == iter->sValue)
            {
                break;
            }
        }
        ++iter;
    }
    return true;
}

static void
_outputString(const std::string &in, std::string &out)
{
    std::string::size_type pos = 0;
    while(pos < in.length())
    {
        switch(in[pos])
        {
            case '\\':
                out += "\\\\";
                break;
            case '\t':
                out += "\\t";
                break;
            case '\n':
                out += "\\n";
                break;
            case '\r':
                out += "\\r";
                break;
            case '\a':
                out += "\\a";
                break;
            case '\b':
                out += "\\b";
                break;
            case '\e':
                out += "\\e";
                break;
            case '\f':
                out += "\\f";
                break;
            case '\v':
                out += "\\v";
                break;
            case '\1':
                out += "\\1";
                break;
            case '\2':
                out += "\\2";
                break;
            case '\3':
                out += "\\3";
                break;
            case '\4':
                out += "\\4";
                break;
            case '\5':
                out += "\\5";
                break;
            case '\6':
                out += "\\6";
                break;
            case '\0':
                out += "\\0";
                break;
            default:
                out += in[pos];
                break;
        }
        ++pos;
    }
}

bool
rcsSvrf2Pvrs::createDCMRuleFile(std::string sInFile, std::string sOutCheckMapFile,
                                bool isOutputGds, bool isOutputOasis, bool isDCMInclude)
{
    std::cout << "\n";
    std::cout << "------        RULE FILE GENERATE CHECKMAP BEGIN           ------\n";
    std::cout << "\n";

    bool isTvf = false;
    isTvf = isTVFRule(sInFile.c_str()) ? true : false;
    if(isTvf)
    {
        rcsTVFCompiler_T tvf2svrf(sInFile);
        tvf2svrf.tvf_compiler();
        sInFile = tvf2svrf.getsvrffilename();
    }

    rcsManager_T::getInstance()->setConvertIncludeFile(false);
    std::ofstream outFile(rcsManager_T::getInstance()->getTmpFileName());
    rcsPreProcessor_T processor(sInFile.c_str(), false, outFile);
    processor.initial();
    processor.execute();
    outFile.flush();
    outFile.close();

    rcsFormat format(rcsManager_T::getInstance()->getTmpFileName());
    format.execute();

    rcsCheckTextExtractor_T extractor(rcsManager_T::getInstance()->getTmpFileName());
    extractor.execute();
    std::list<rcsToken_T> tokens;
    std::set<hvUInt32> vUnstoredCommentLineNumbers;
    rcsLexParser_T lexparser(tokens, vUnstoredCommentLineNumbers);
    lexparser.parse(rcsManager_T::getInstance()->getTmpFileName());

    std::ofstream out(sOutCheckMapFile);
    if(!out.is_open())
        return false;
    {
        std::ofstream checkMapFile(".__checkmap.def");
        srand((int)time(NULL));
        bool isGdsOut = (rand() % 2) != 0;

        if(isOutputGds)
        {
            isGdsOut = true;
        }
        else if(isOutputOasis)
        {
            isGdsOut = false;
        }
        hvUInt32 nErcPathchk = 0;
        std::vector<rcsToken_T> vRuleNames;
        {
            std::list<rcsToken_T>::iterator iter = tokens.begin();
            while(iter != tokens.end())
            {
                switch(iter->eType)
                {
                    case SPECIFICATION_KEYWORD:
                    {
                        if(iter->eKeyType == DRC_RESULTS_DATABASE ||
                           iter->eKeyType == DRC_MAXIMUM_VERTEX ||
                           iter->eKeyType == DRC_CHECK_MAP ||
                           iter->eKeyType == DRC_MAXIMUM_RESULTS ||
                           iter->eKeyType == DRC_SUMMARY_REPORT ||
                           iter->eKeyType == ERC_SUMMARY_REPORT ||
                           iter->eKeyType == ERC_RESULTS_DATABASE ||
                           iter->eKeyType == ERC_MAXIMUM_RESULTS ||
                           iter->eKeyType == ERC_MAXIMUM_VERTEX ||
                           iter->eKeyType == ERC_CELL_NAME ||
                           iter->eKeyType == MASK_SVDB_DIRECTORY)
                        {
                            std::list<rcsToken_T>::iterator begin = iter;
                            parseSpecification(iter, &tokens);
                            iter = tokens.erase(begin, iter);
                            continue;
                        }
                        else if(iter->eKeyType == ERC_PATHCHK)
                        {
                            std::list<rcsToken_T>::iterator begin = iter;
                            parseSpecification(iter, &tokens);

                            char _buf[128];
                            sprintf(_buf, "RULE_ERC_PATHCHK_%u", nErcPathchk);

                            rcsToken_T _t;
                            _t.eType = IDENTIFIER_NAME;
                            _t.sValue = _buf;
                            vRuleNames.push_back(_t);

                            begin->sValue = _buf;
                            begin->sValue+= " { pathchk";
                            std::list<rcsToken_T>::iterator _i = begin;
                            for(++ _i; _i != iter; ++ _i)
                            {
                                begin->sValue+= " ";
                                begin->sValue+= _i->sValue;
                            }
                            begin->sValue+= " }";

                            iter = tokens.erase(++ begin, iter);
                            ++ nErcPathchk;
                            continue;
                        }
                        break;
                    }
                    case SEPARATOR:
                    {
                        if(iter->sValue == "{")
                        {
                            std::list<rcsToken_T>::iterator begin = iter;
                            vRuleNames.push_back(*(--begin));

                            while(begin != tokens.begin())
                            {
                                if(begin->eType == SPECIFICATION_KEYWORD ||
                                   begin->eType == LAYER_OPERATION_KEYWORD ||
                                   begin->eType == DMACRO)
                                    break;

                                --begin;
                            }

                            if(begin->eType == DMACRO)
                            {
                                bool _h = false;
                                hvUInt32 _n = 0;
                                for(std::list<rcsToken_T>::iterator _i = ++ begin; _i != iter; ++ _i)
                                {
                                    if(SEPARATOR == _i->eType)
                                    {
                                        if(_i->sValue == "{")
                                            ++ _n, _h = true;
                                        else if(_i->sValue == "}")
                                            -- _n;
                                    }
                                }

                                if(!_h || _n != 0)
                                    vRuleNames.pop_back();
                            }
                        }
                        break;
                    }
                    default:
                        break;
                }
                ++iter;
            }

            {
            if(!isDCMInclude)
            {
            	bool isBuildInLang = false;
                iter = tokens.begin();
                std::list<rcsToken_T>::iterator iPre = iter;
                bool isDfmRdbAscii = false;
                while(iter != tokens.end())
                {
                    if(iter->eType == LAYER_OPERATION_KEYWORD)
                    {
                        isDfmRdbAscii = iter->eKeyType == DFM_RDB_ASCII;
                    }
                    if(iter->eType == STRING_CONSTANTS)
                    {
                        std::string sValue;
                        _outputString(iter->sValue, sValue);
                        out << "\"" << sValue << "\"" << " ";
                    }
                    else if( (iter->eType != COMMENT) || (iter->sValue[0] == '@') )
                    {
                    	if(iter->eType == SEPARATOR && iter->sValue.compare("[") == 0)
                    	{
                            if(isDfmRdbAscii)
                            {
                                while (iter != tokens.end())
                                {
                                    out << iter->sValue;
                                    if(iter->sValue.compare("]") == 0)
                                    {
                                        ++iter;
                                        break;
                                    }
                                    ++iter;
                                }
                            }
                            else
                    		    isBuildInLang = true;
                    	}

                    	if(iter->sValue.compare("]") == 0 && isBuildInLang)
                    	{
                    	    isBuildInLang = false;
                    	}

                    	if(iter->eType == BLANK_SPACE && isBuildInLang)
                    	{
                    		++iter;
                    		continue;
                    	}
                    	if((iter->sValue[0] == '@'))        // ones60831
                    	{
                            std::string str = iter->sValue;
                            str.erase(0,1);
                            trim(str);
                            if(0 == strncasecmp(str.c_str(), "#pragma", 7))
                                out << str.c_str() << " ";
                            else
                                out << iter->sValue << " ";
                    	}
                    	else
                    	{
                    	    out << iter->sValue << " ";
                    	}
                    }
                    else
                    {
                        iPre = iter;
                        ++iter;
                        continue;
                    }

                    iPre = iter;
                    ++iter;
                    if(iPre->nLineNo != iter->nLineNo)
                        out << "\n";
                }
            }
                if(nErcPathchk > 0)
                {
                    out << "GROUP ERC_PATHCHK_G RULE_ERC_PATHCHK_?\n";
                    out << "ERC SELECT CHECK ERC_PATHCHK_G\n";
                    checkMapFile << "GROUP ERC_PATHCHK_G RULE_ERC_PATHCHK_?\n";
                    checkMapFile << "ERC SELECT CHECK ERC_PATHCHK_G\n";
                }

                out << "DRC MAXIMUM RESULTS ALL\n";
                checkMapFile << "DRC MAXIMUM RESULTS ALL\n";
                if(isGdsOut)
                {
                	out << "DRC RESULTS DATABASE drc.out.asc\n";
                	checkMapFile << "DRC RESULTS DATABASE drc.out.asc\n\n";
                }
                else
                {
                	out << "DRC RESULTS DATABASE drc.out.oas OASIS NOCBLOCK\n";
                	checkMapFile << "DRC RESULTS DATABASE drc.out.oas OASIS NOCBLOCK\n\n";
                }
                out << "DRC SUMMARY REPORT drc.sum\n\n";
                out << "ERC MAXIMUM RESULTS ALL\n";
                out << "ERC RESULTS DATABASE erc.out\n";
                out << "ERC SUMMARY REPORT erc.sum\n";
                out << "ERC CELL NAME YES CELL SPACE\n\n";

                hvUInt32 iRule = 0;
                hvUInt32 iValidRule = 0;
                for(; iRule != vRuleNames.size(); ++iRule)
                {
                	trim(vRuleNames[iRule].sValue);
                	if(vRuleNames[iRule].sValue.empty() ||
                       (vRuleNames[iRule].sValue.compare("else") == 0) ||
                       (vRuleNames[iRule].sValue.compare("if") == 0))
                	{
                		continue;
                	}

                    out << "DRC CHECK MAP ";
                    checkMapFile << "DRC CHECK MAP ";
                    if(vRuleNames[iRule].eType == STRING_CONSTANTS)
                    {
                        std::string sValue;
                        _outputString(vRuleNames[iRule].sValue, sValue);
                        out << "\"" << sValue << "\"" << " ";
                        checkMapFile << "\"" << sValue << "\"" << " ";
                    }
                    else
                    {
                        out << vRuleNames[iRule].sValue;
                        checkMapFile << vRuleNames[iRule].sValue;
                    }
                    out << " ASCII drc.out.asc MAXIMUM RESULTS ALL MAXIMUM VERTICES 1024\n";
                    checkMapFile << " ASCII drc.out.asc MAXIMUM RESULTS ALL MAXIMUM VERTICES 1024\n";

                    out << "DRC CHECK MAP ";
                    checkMapFile << "DRC CHECK MAP ";
                    if(vRuleNames[iRule].eType == STRING_CONSTANTS)
                    {
                        std::string sValue;
                        _outputString(vRuleNames[iRule].sValue, sValue);
                        out << "\"" << sValue << "\"" << " ";
                        checkMapFile << "\"" << sValue << "\"" << " ";
                    }
                    else
                    {
                        out << vRuleNames[iRule].sValue;
                        checkMapFile << vRuleNames[iRule].sValue;
                    }

                    if(isGdsOut)
                    {
                        out << " GDSII ";
                        checkMapFile << " GDSII ";
                    }
                    else
                    {
                        out << " OASIS ";
                        checkMapFile << " OASIS ";
                    }

                    out << (iValidRule + 1) << " 0 drc.out.";
                    checkMapFile << (iValidRule + 1) << " 0 drc.out.";

                    if(isGdsOut)
					{
                        out << "gds MAXIMUM RESULTS ALL MAXIMUM VERTICES 1024\n";
                        checkMapFile << "gds MAXIMUM RESULTS ALL MAXIMUM VERTICES 1024\n";
					}
					else
					{
                        out << "oas MAXIMUM RESULTS ALL MAXIMUM VERTICES 1024\n";
                        checkMapFile << "oas MAXIMUM RESULTS ALL MAXIMUM VERTICES 1024\n";
					}

                    iValidRule++;
                }
                if(isDCMInclude)
                {
                    out << "\nDRC ICSTATION YES\n";
                    out << "INCLUDE " << sInFile <<  "\n";
                }
            }
        }
    }
    if(!out.good())
        return false;
    out.close();

    std::cout << "\n";
    std::cout << "------        RULE FILE GENERATE CHECKMAP END           ------\n";
    std::cout << "\n";
    return true;
}

bool
rcsSvrf2Pvrs::createCheckRuleFile(std::string sInFile, std::string sOutCheckFile)
{
    std::cout << "\n";
    std::cout << "------        RULE FILE GENERATE CHECKFILE BEGIN           ------\n";
    std::cout << "\n";

    bool isTvf = false;
    isTvf = isTVFRule(sInFile.c_str()) ? true : false;
    if(isTvf)
    {
        rcsTVFCompiler_T tvf2svrf(sInFile);
        tvf2svrf.setcheckoptionflag();
        tvf2svrf.tvf_compiler();
        sInFile = tvf2svrf.getsvrffilename();
    }

    rcsManager_T::getInstance()->setConvertIncludeFile(false);
    std::ofstream outFile(rcsManager_T::getInstance()->getTmpFileName());
    rcsPreProcessor_T processor(sInFile.c_str(), false, outFile);
    processor.initial();
    processor.execute();
    outFile.flush();
    outFile.close();

    rcsFormat format(rcsManager_T::getInstance()->getTmpFileName());
    format.execute();

    rcsCheckTextExtractor_T extractor(rcsManager_T::getInstance()->getTmpFileName());
    extractor.execute();

    std::ofstream out(sOutCheckFile);
    if(!out.is_open())
        return false;

    std::istream *pReader = NULL;
    const char *pFileName = rcsManager_T::getInstance()->getTmpFileName();

    if(pFileName != NULL)
    {
       pReader = new std::ifstream(pFileName);
    }

    bool needTransBuiltIn = true;
    bool isInBuildInLang = false;
    FlexLexer *pLexer = new yyFlexLexer(pReader);
    hvInt32 eType = pLexer->yylex();
    std::pair<hvInt32, std::string> pairCommandInfo(-1u, "");
    while(eType)
    {
        if(eType == NON_SUPPORT_COMMAND || eType == NON_SUPPORT_OPERTION || eType == NON_SUPPORT_SPECIFICATION)
        {
            rcErrManager_T::Singleton().reportFileInfo(pLexer->lineno(), out);
            out << " ==> " << pLexer->YYText() << std::endl;
            pairCommandInfo = std::make_pair(eType, pLexer->YYText());
            needTransBuiltIn = true;
        }
        else if((eType >= AND && eType < DEVICE) || (eType >= DEVICE && eType < NON_SUPPORT_SPECIFICATION))
        {
            switch(eType)
            {
                case DFM_ANALYZE:
                case DFM_ASSERT:
                case DFM_BALANCE:
                case DFM_CAF:
                case DFM_CRITICAL_AREA:
                case DFM_DATABASE:
                case DFM_DV_ANALYZE:
                case DFM_MEASURE :
                case DFM_HISTOGRAM:
                case DFM_PARTITION:
                case DFM_REDUNDANT_VIAS:
                case DFM_NON_REDUNDANT_VIAS:
                case DFM_REMOVE_EDGE:
                case DFM_SPEC_BALANCE:
                case DFM_SPEC_RANDOM_SPOT_FAULT:
                case DFM_SPEC_VIA:
                case DFM_SPEC_VIA_REDUNDANCY:
                case DFM_SUMMARY_REPORT:
                case DFM_TRANSITION :
                case DFM_YS_AUTOSTART :
                case DRC_PRINT_EXTENT:
                case LAYOUT_NET_LIST:
                case PORT_LAYER_MERGED_POLYGON:
                case DFM_CLASSIFY:
                case DFM_CREATE_LAYER_POLYGONS:

                case ERC_TVF:
                case LVS_APPLY_UNUSED_FILTER:
                case LVS_CENTER_DEVICE_LOCATION:
                case LVS_CENTER_DEVICE_PINS:
                case LVS_COMPONENT_SUBTYPE_PROPERTY:
                case LVS_COMPONENT_TYPE_PROPERTY:
                case LVS_CONFIGURE_UNUSED_FILTER:
                case LVS_MOS_SWAPPABLE_PROPERTIES:
                case LVS_NETLIST_CONNECT_PORT_NAMES:
                case LVS_NETLIST_UNNAMED_ISOLATED_NETS:
                case LVS_NL_PIN_LOCATIONS:
                case LVS_RECOGNIZE_GATES_TOLERANCE:
                case LVS_SIGNATURE_MAXIMUM:
                case MASK_RESULTS_DATABASE:

                case DENSITY_CONVOLVE:
                case DRC_AUTO_ERROR:
                case LAYOUT_CLONE_BY_LAYER:
                case LAYOUT_PATH_WIDTH_MULTIPLE:
                case LAYOUT_PATH_EXTENSION_MULTIPLE:
                case LAYOUT_PLACEMENT_MULTIPLE:                
                case LAYOUT_PROPERTY_AUDIT:
                case LAYOUT_RENAME_ICV:
                case OFFGRID_DIR:
                case SVRF_PROPERTY:
                case SVRF_VERSION:
                case LAYOUT_CELL_MATCH_RULE:
                {
                    rcErrManager_T::Singleton().reportFileInfo(pLexer->lineno(), out);
                    out << " ==> " << pLexer->YYText() << std::endl;
                    break;
                }
                default:
                {
                    break;
                }

            }

            pairCommandInfo = std::make_pair(eType, pLexer->YYText());
            needTransBuiltIn = eType != TVF_FUNCTION && eType != DFM_SPEC_FILL_SHAPE;
            needTransBuiltIn = eType != EXTERNAL && eType != ENCLOSURE && eType != INTERNAL && eType != TDDRC;

        }
        else if (eType >= ABUT_ALSO)
        {
            if (pairCommandInfo.first != -1u)
            {
                hvInt32 eCommandType = pairCommandInfo.first;
                switch (eCommandType)
                {
                    case DFM_DP:
                    {
                        switch(eType)
                        {
                            case NOT_SUPPORT_OPTION:
                            case PREFER:
                            case WAIVER:
                            {
                                rcErrManager_T::Singleton().reportFileInfo(pLexer->lineno(), out);
                                out << " ==> " << pairCommandInfo.second << " : " << pLexer->YYText() << std::endl;
                            }
                        }
                        break;
                    }
                    case DFM_MP:
                    {
                        switch(eType)
                        {
                            case NOT_SUPPORT_OPTION:
                            case SAME:
                            case USER:
                            case MINIMIZE:
                            case MAXIMIZE:
                            {
                                rcErrManager_T::Singleton().reportFileInfo(pLexer->lineno(), out);
                                out << " ==> " << pairCommandInfo.second << " : " << pLexer->YYText() << std::endl;
                            }
                        }
                        break;
                    }
                    case LAYOUT_INPUT_EXCEPTION_SEVERITY:
                    {
                        switch(eType)
                        {
                            case NOT_SUPPORT_OPTION:
                            case LAYER_OVER_BUMP_EXCEPT:
                            {
                                rcErrManager_T::Singleton().reportFileInfo(pLexer->lineno(), out);
                                out << " ==> " << pairCommandInfo.second << " : " << pLexer->YYText() << std::endl;
                            }
                        }
                        break;
                    }
                    case DFM_RDB:
                    {
                        switch(eType)
                        {
                            case NOT_SUPPORT_OPTION:
                            case NODAL:
                            case JOINED:
                            case ALL_CELLS:
                            case TRANSITION:
                            case ABUT_ALSO:
                            case RESULT_CELLS:
                            case ANNOTATE:
                            case CELL_SPACE:
                            case GDSII:
                            case OASIS:
                            {
                                rcErrManager_T::Singleton().reportFileInfo(pLexer->lineno(), out);
                                out << " ==> " << pairCommandInfo.second << " : " << pLexer->YYText() << std::endl;
                                break;
                            }
                        }
                        break;
                    }
                    default:
                    {
                        switch(eType)
                        {
                            case NOT_SUPPORT_OPTION:
                            {
                                rcErrManager_T::Singleton().reportFileInfo(pLexer->lineno(), out);
                                out << " ==> " << pairCommandInfo.second << " : " << pLexer->YYText() << std::endl;
                            }
                        }
                        break;

                    }
                }
            }
        }
        else if(eType == SEPARATOR && strcasecmp(pLexer->YYText(), "[") == 0)
        {
            isInBuildInLang = true;
        }
        else if(eType == SEPARATOR && isInBuildInLang && strcasecmp(pLexer->YYText(), "]") == 0)
        {
            isInBuildInLang = false;
        }
        else if(eType == IDENTIFIER_NAME && needTransBuiltIn && isInBuildInLang)
        {
            if (pairCommandInfo.first != -1u)
            {
                if (strcasecmp(pLexer->YYText(), "emptystring") == 0
                        || strcasecmp(pLexer->YYText(), "find_sorted") == 0
                        || strcasecmp(pLexer->YYText(), "match") == 0
                        || strcasecmp(pLexer->YYText(), "netname") == 0
                        || strcasecmp(pLexer->YYText(), "netvelement") == 0
                        || strcasecmp(pLexer->YYText(), "netvtuple") == 0
                        || strcasecmp(pLexer->YYText(), "nonetid") == 0
                        || strcasecmp(pLexer->YYText(), "normalize_xy") == 0
                        || strcasecmp(pLexer->YYText(), "precision") == 0
                        || strcasecmp(pLexer->YYText(), "presorted") == 0
                        || strcasecmp(pLexer->YYText(), "random") == 0
                        || strcasecmp(pLexer->YYText(), "psnetid") == 0
                        || strcasecmp(pLexer->YYText(), "sort") == 0
                        || strcasecmp(pLexer->YYText(), "sort_index") == 0
                        || strcasecmp(pLexer->YYText(), "sort_unique") == 0
                        || strcasecmp(pLexer->YYText(), "sort_unique_index") == 0
                        || strcasecmp(pLexer->YYText(), "svelement") == 0
                        || strcasecmp(pLexer->YYText(), "svtuple") == 0
                        || strcasecmp(pLexer->YYText(), "unique") == 0
                        || strcasecmp(pLexer->YYText(), "unique_index") == 0
                        || strcasecmp(pLexer->YYText(), "velement") == 0
                        || strcasecmp(pLexer->YYText(), "vtuple") == 0
                        || strcasecmp(pLexer->YYText(), "ordinal") == 0)
               {
                   rcErrManager_T::Singleton().reportFileInfo(pLexer->lineno(), out);
                   out << " ==> not support DFM FUNCTION" << " : " << pLexer->YYText() << std::endl;
               }
            }
        }
        eType = pLexer->yylex();
    }


    if(!out.good())
        return false;
    out.close();

    std::cout << "\n";
    std::cout << "------        RULE FILE GENERATE CHECKFILE END           ------\n";
    std::cout << "\n";
    return true;
}

void
rcsSvrf2Pvrs::initUsrPvrsKeyWordSet()
{
	const char *pValue = g_warpper_getenv("PVCONVERTOR_HOME");
	if(NULL != pValue)
	{
		string strPvrsKeyWordCfg(pValue);
		strPvrsKeyWordCfg.append("/pvconvertor/pvrsKeyWord.list");
		std::ifstream fRead;
		fRead.open(strPvrsKeyWordCfg.c_str());
		string strTmp;
		while(getline(fRead,strTmp))
		{
			trim(strTmp);
			rcsManager_T::getInstance()->addUsrPvrsKeyWord(strTmp);
		}
		fRead.close();
	}
}

bool
rcsSvrf2Pvrs::execute(std::string sInFile, const std::string &sSwitchFile,
                      const std::string &sOutFile, bool outSvrf,
                      bool convertSwitch, bool flattenMacro, bool outComment,
                      std::ostream &out, bool isNewPvrs, bool needExpandTmpLayer,
                      bool convertIncludeFile, bool trsFlag,
                      const std::string &sTmpLayerSuffix)
{
    try
    {
        rcsManager_T::getInstance()->setPVRSOutFile(sOutFile);
        bool bOpen = rcsManager_T::getInstance()->beginWrite();
        if (!bOpen)
        {
            s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, sOutFile), out);
            s_errManager.Report(out);
            rcsManager_T::getInstance()->endWrite();
            return false;
        }
        rcsManager_T::getInstance()->setOutputComment(outComment);
        rcsManager_T::getInstance()->setOutputSvrfComment(outSvrf);
        rcsManager_T::getInstance()->setExpandTmpLayer(needExpandTmpLayer);
        rcsManager_T::getInstance()->setNewPvrs(isNewPvrs);
        rcsManager_T::getInstance()->setFlattenMacro(flattenMacro);
        rcsManager_T::getInstance()->setConvertSwitch(convertSwitch);
        rcsManager_T::getInstance()->setConvertIncludeFile(convertIncludeFile);
        rcsManager_T::getInstance()->setTvf2Trs(trsFlag);
        rcsManager_T::getInstance()->setTrsFlag(trsFlag);
        rcsManager_T::getInstance()->setTmpLayerSuffix(sTmpLayerSuffix);

        if(!sSwitchFile.empty())
            convertSwitch = false;

        bool isTvf = false;
        std::string fileType = "";
        std::string includeFlag = (rcsManager_T::getInstance()->isConvertIncludeFile() &&
								   !rcsManager_T::getInstance()->isFirstTime()) ? "INCLUDE" : "";
        isTvf = isTVFRule(sInFile.c_str()) ? true : false;
        if(isTvf && convertSwitch)
        {
            trsFlag = true;
            rcsManager_T::getInstance()->setTvf2Trs(true);
            rcsManager_T::getInstance()->setTrsFlag(true);
            rcsManager_T::getInstance()->setConvertSwitch(false);
            convertSwitch = false;
        }
        fileType = isTvf ? " TVF " : " SVRF ";
        rcsManager_T::getInstance()->setTvfFile(isTvf);

        // if(!isTvf && trsFlag)
        // {
        // 	out << "\n";
        // 	out << "Run Error:Rule File is not TVF format, can't use \"-trs\" option, please delete it.\n";
        // 	out << "\n";
        // 	return false;
        // }

        out << "\n";
		out << "------        " << includeFlag << fileType << "RULE FILE CONVERTOR BEGIN           ------\n";
		out << "\n";

#ifdef DEBUG
		out << "inputFile:" << sInFile << std::endl;
		out << "outputFile:" << sOutFile << std::endl;
#endif

        if(access(sInFile.c_str(), F_OK|R_OK) != 0)
        {
            s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, sInFile), out);
            s_errManager.Report(out);
            rcsManager_T::getInstance()->endWrite();
            return false;
        }

        struct stat filestat;
        stat(sInFile.c_str(), &filestat);
        if(!S_ISREG(filestat.st_mode))
        {
            s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, sInFile), out);
            s_errManager.Report(out);
            rcsManager_T::getInstance()->endWrite();

            return false;
        }

        if(isTvf && rcsManager_T::getInstance()->isTvf2Trs())
        {
            rcsTvfConvertor convertor(sInFile);
            convertor.execute();
            rcsManager_T::getInstance()->endWrite();

            if(convertor.hasDeviceFuncCall() && convertor.hasDviceFuncLimit())
            {
                const char *pStr = getenv("PVCONVERTOR_HOME");
                std::string sTclPkgFile;
                sTclPkgFile += pStr;
                sTclPkgFile += "/pvconvertor/share/enc_all.tcl";
                std::fstream file(sOutFile.c_str());
                std::stringstream sFileCotent;
                if(copyOrSourceTrsPackage(sTclPkgFile, sFileCotent, out))
                {
                    file.seekg(strlen("#!trs"), std::ios::beg);
                    sFileCotent << file.rdbuf();
                    file.close();

                    file.open(sOutFile, std::fstream::out | std::fstream::trunc);
                    file << sFileCotent.rdbuf();
                }

                file.close();
            }

            out << "\n";
            out << "------        " << includeFlag << fileType << "RULE FILE CONVERTOR FINISHED        ------\n";
            out << "\n";



            return true;
        }
        else if(isTvf && !rcsManager_T::getInstance()->isTvf2Trs())
        {
            rcsTVFCompiler_T tvf2svrf(sInFile);

            int n = tvf2svrf.tvf_compiler();
            if(n != 0)
            {
                s_errManager.Report(out);
                rcsManager_T::getInstance()->endWrite();

                out << "\n";
                out << "------        " << includeFlag << fileType << "RULE FILE CONVERTOR FAILED          ------\n\n";
                out << "\n";
                return false;
            }

            sInFile = tvf2svrf.getsvrffilename();
        }

        if(!sSwitchFile.empty())
        {
            convertSwitch = false;

            std::string sTmpFile = ".svrf2pvrs.switch.tmp";
            std::ofstream writer(sTmpFile.c_str());
            writer << "INCLUDE \"" << sSwitchFile << "\"" << std::endl;
            writer << "INCLUDE \"" << sInFile << "\"" << std::endl;
            writer.close();

            sInFile = sTmpFile;
        }

        if(!convertSwitch)
            flattenMacro  = true;

        std::ofstream outFile(rcsManager_T::getInstance()->getTmpFileName());
        if (!outFile)
        {
            s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, rcsManager_T::getInstance()->getTmpFileName()), out);
            s_errManager.Report(out);
            rcsManager_T::getInstance()->endWrite();
            return false;
        }
        rcsPreProcessor_T processor(sInFile.c_str(), convertSwitch, outFile);
        processor.initial(this->getLastGlobalLine());
        processor.execute();
        outFile.flush();
        outFile.close();

#ifdef __DEBUG__
        {
            std::cout << "-------------- AFTER PREPROCESS ---------------" << std::endl;
            std::ifstream reader(rcsManager_T::getInstance()->getTmpFileName());
            std::string line;
            while (getline(reader, line))
            {
                std::cout << line << std::endl;
            }
            std::cout << std::endl;
        }
#endif



        if(isTvf)
        {
        	rcsFormat format(rcsManager_T::getInstance()->getTmpFileName());
        	format.execute();
        }

		rcsCheckTextExtractor_T extractor(rcsManager_T::getInstance()->getTmpFileName());
		extractor.execute();
		std::list<rcsToken_T> tokens;
		std::set<hvUInt32> vUnstoredCommentLineNumbers;
		rcsLexParser_T lexparser(tokens, vUnstoredCommentLineNumbers);
		lexparser.parse(rcsManager_T::getInstance()->getTmpFileName());

#ifdef __DEBUG__
        {
		    std::cout << "\n----------- AFTER LEX PARSER ----------------\n";
		    printTokenStream(tokens.begin(), tokens.end());
		    std::cout << std::endl;
        }
#endif

        std::map<hvUInt32, std::pair<hvUInt32, bool> > blankLinesBefore;
		rcsLexMacroParser_T macroparser(tokens, blankLinesBefore, vUnstoredCommentLineNumbers, flattenMacro, convertSwitch);
		macroparser.parse();

        transGlobalLineForIncFile(tokens);

#ifdef __DEBUG__
        {
		    std::cout << "\n----------- AFTER MACRO PARSER ----------------\n";
		    printTokenStream(tokens.begin(), tokens.end());
		    std::cout << std::endl;
        }
#endif

		rcsSynConvertor convertor(tokens);

        if (!flattenMacro)
            convertor.setMacroParaMap(&macroparser.m_macrosParaSizeMap);

		rcsSynRootNode_T *pNode = convertor.execute(blankLinesBefore);

		delete pNode;


        if(isTvf)
            remove(rcsTVFCompiler_T::getsvrffilename());

        remove(".svrf2pvrs.switch.tmp");
        remove(rcsManager_T::getInstance()->getTmpFileName());

        out << "\n";
        out << "------        " << includeFlag << fileType << "RULE FILE CONVERTOR FINISHED        ------\n\n";
        out << "\n";

        s_errManager.Report(out);
        rcsManager_T::getInstance()->endWrite();
        processIncludeFileRespectively(processor);

        return true;
    }
    catch(const rcErrorNode_T &error)
    {
        s_errManager.addError(error, out);
    }
    return false;
}

bool
rcsSvrf2Pvrs::executeIncludeFile(std::string sInFile, const std::string &sSwitchFile,
							const std::string &sOutFile, std::ostream &out)
{
    try
    {
        rcsManager_T::getInstance()->setPVRSOutFile(sOutFile);
        rcsManager_T::getInstance()->setFirstTime(false);
        bool bOpen = rcsManager_T::getInstance()->beginWrite();
        if (!bOpen)
        {
            s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, sOutFile), out);
            s_errManager.Report(out);
            rcsManager_T::getInstance()->endWrite();
            return false;
        }
        bool convertSwitch 		= rcsManager_T::getInstance()->isConvertSwitch();
        bool flattenMacro 		= rcsManager_T::getInstance()->isFlattenMacro();

        if(!sSwitchFile.empty())
            convertSwitch = false;

        std::string fileType = "TVF";
        std::string includeFlag = "INCLUDE";

        out << "\n";
		out << "------        " << includeFlag << fileType << "RULE FILE CONVERTOR BEGIN           ------\n";
		out << "\n";

        if(access(sInFile.c_str(), F_OK|R_OK) != 0)
        {
            s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, sInFile), out);
            s_errManager.Report(out);
            rcsManager_T::getInstance()->endWrite();
            return false;
        }

        struct stat filestat;
        stat(sInFile.c_str(), &filestat);
        if(!S_ISREG(filestat.st_mode))
        {
            s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, sInFile), out);
            s_errManager.Report(out);
            rcsManager_T::getInstance()->endWrite();
            return false;
        }

        if(rcsManager_T::getInstance()->isTvf2Trs())
        {
            rcsTvfConvertor convertor(sInFile);
            convertor.execute();

            if(rcsManager_T::getInstance()->isConvertIncludeFile())
            {
            	rcsManager_T::getInstance()->endWrite();
            }

            out << "\n";
            out << "------        " <<  includeFlag << fileType << "RULE FILE CONVERTOR FINISHED        ------\n";
            out << "\n";

            return true;
        }
        else if(rcsManager_T::getInstance()->isTvf2Trs())
        {
            rcsTVFCompiler_T tvf2svrf(sInFile);

            int n = tvf2svrf.tvf_compiler();
            if(n != 0)
            {
                s_errManager.Report(out);
                rcsManager_T::getInstance()->endWrite();

                out << "\n";
                out << "------        " << includeFlag << fileType << "RULE FILE CONVERTOR FAILED          ------\n\n";
                out << "\n";
                return false;
            }

            sInFile = tvf2svrf.getsvrffilename();
        }

        if(!sSwitchFile.empty())
        {
            convertSwitch = false;

            std::string sTmpFile = ".svrf2pvrs.switch.tmp";
            std::ofstream writer(sTmpFile.c_str());
            writer << "INCLUDE \"" << sSwitchFile << "\"" << std::endl;
            writer << "INCLUDE \"" << sInFile << "\"" << std::endl;
            writer.close();

            sInFile = sTmpFile;
        }

        if(!convertSwitch)
            flattenMacro  = true;

        std::ofstream outFile(rcsManager_T::getInstance()->getTmpFileName());
        rcsPreProcessor_T processor(sInFile.c_str(), convertSwitch, outFile);
        processor.initial();
        processor.execute();
        outFile.flush();
        outFile.close();

        rcsFormat format(rcsManager_T::getInstance()->getTmpFileName());
        format.execute();

        rcsCheckTextExtractor_T extractor(rcsManager_T::getInstance()->getTmpFileName());
        extractor.execute();
        std::list<rcsToken_T> tokens;
        std::set<hvUInt32> vUnstoredCommentLineNumbers;
        rcsLexParser_T lexparser(tokens, vUnstoredCommentLineNumbers);
        lexparser.parse(rcsManager_T::getInstance()->getTmpFileName());
        std::map<hvUInt32, std::pair<hvUInt32, bool> > blankLinesBefore;
        rcsLexMacroParser_T macroparser(tokens, blankLinesBefore, vUnstoredCommentLineNumbers, flattenMacro, convertSwitch);
        macroparser.parse();
        rcsSynConvertor convertor(tokens);
        rcsSynRootNode_T *pNode = convertor.execute(blankLinesBefore);

        delete pNode;

        remove(rcsTVFCompiler_T::getsvrffilename());

        remove(".svrf2pvrs.switch.tmp");
        remove(rcsManager_T::getInstance()->getTmpFileName());

        out << "\n";
        out << "------        " <<  includeFlag << fileType << "RULE FILE CONVERTOR FINISHED        ------\n\n";
        out << "\n";

        

        if(!rcsManager_T::getInstance()->isConvertIncludeFile())
        {
        	rcsManager_T::getInstance()->endWrite();
        }

        return true;
    }
    catch(const rcErrorNode_T &error)
    {
        s_errManager.addError(error, out);
    }
    return false;
}

bool
rcsSvrf2Pvrs::executeTvfPreprocess(std::string sInFile, const std::string &sOutFile, std::ostream &out)
{
    std::string fileType = "";
    bool isTRS = false;
    bool isTVF = false;
    isTVFRule(sInFile.c_str(), &isTVF, &isTRS);

    if(isTVF)
    {
    	fileType = " TVF ";
    	out << "\n";
		out << "------        " << fileType << "RULE FILE PPEPROCESSOR BEGIN           ------\n\n";
		out << "\n";

        rcsTVFCompiler_T tvf2svrf(sInFile, sOutFile);
	    int n = tvf2svrf.tvf_compiler();
	    if(n != 0)
	    {
	        s_errManager.Report(out);

	        out << "\n";
	        out << "------        " << fileType << "RULE FILE PPEPROCESSOR FAILED          ------\n\n";
	        out << "\n";
	        return false;
	    }
	    else
	    {
	        out << "\n";
	    	out << "------        " << fileType << "RULE FILE PPEPROCESSOR FINISHED        ------\n\n";
	    	out << "\n";
	    	return true;
	    }
    }
    else if(isTRS)
    {
    	fileType = " TRS ";
    	out << "\n";
		out << "------        " << fileType << "RULE FILE PPEPROCESSOR BEGIN           ------\n\n";
		out << "\n";

        rcpTRSCompiler trs2pvrs(sInFile.c_str(), sOutFile.c_str());
	    int n = trs2pvrs.trs_compiler();
	    if(n != 0)
	    {
	        s_errManager.Report(out);

	        out << "\n";
	        out << "------        " << fileType << "RULE FILE PPEPROCESSOR FAILED        ------\n\n";
	        out << "\n";
	        return false;
	    }
	    else
	    {
	        out << "\n";
	    	out << "------        " << fileType << "RULE FILE PPEPROCESSOR FINISHED        ------\n\n";
	    	out << "\n";
	    	return true;
	    }
    }
    else
    {
    	out << "Error: The rule file is not TVF or TRS format! \n";
    	return false;
    }
}

hvUInt32
rcsSvrf2Pvrs::increaseCurLineNo(hvUInt32 step)
{
	return rcsSvrf2Pvrs::mCurLineNo += step;
}

hvUInt32
rcsSvrf2Pvrs::decreaseCurLineNo()
{
	return --rcsSvrf2Pvrs::mCurLineNo;
}

hvUInt32
rcsSvrf2Pvrs::setCurLineNo(hvUInt32 lineNo)
{
	rcsSvrf2Pvrs::mCurLineNo = lineNo;
	return rcsSvrf2Pvrs::mCurLineNo;
}

hvUInt32
rcsSvrf2Pvrs::getCurLineNo()
{
	return rcsSvrf2Pvrs::mCurLineNo;
}

void
rcsSvrf2Pvrs::setCompleteStr(std::string& str)
{
	mCompleteStr = str;
}

void
rcsSvrf2Pvrs::setStrSearchBegin(hvUInt32 pos)
{
	mStrSearchBegin = pos;
}

hvUInt32
rcsSvrf2Pvrs::findLineNumInTvfFun(std::string command)
{
	hvUInt32 nLines = 0;
	std::string::size_type found;
	if(mCompleteStr != "")
	{
		found = mCompleteStr.find(command, mStrSearchBegin);
		std::string substr = mCompleteStr.substr(mStrSearchBegin, found - mStrSearchBegin);
		for(hvUInt32 i = 0; i < substr.size(); i++)
		{
			if(substr[i] == '\n')
				nLines++;
		}
		mStrSearchBegin = found + command.size();
	}
    return nLines;
}

#ifdef DEBUG
void
printTokenStream(std::list<rcsToken_T>::iterator first, std::list<rcsToken_T>::iterator last)
{
    hvUInt32 nLineNo = first->nLineNo;
    while (first != last)
    {
        if (nLineNo != first->nLineNo)
        {
            std::cout << "\n";
            nLineNo = first->nLineNo;
        }
        std::cout << first->sValue << "(" << first->eType << "," << first->eKeyType << ") ";
        first++;
        std::cout<< "\n=#=";
    }
    std::cout << std::endl;
}
#endif

bool rcsSvrf2Pvrs::copyOrSourceTrsPackage(std::string pTrsPkgFile, std::stringstream &out, std::ostream &errout)
{
    if(access(pTrsPkgFile.c_str(), F_OK|R_OK) != 0)
    {
        s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, pTrsPkgFile), errout);
        s_errManager.Report(errout);
        return false;
    }

    std::string trspkg;
    FILE *pTrsPkg = fopen(pTrsPkgFile.c_str(), "r");
    if(pTrsPkg == NULL)
    {
        std::cerr << "Error: problem with access, file type, or file open of file: "
                  << pTrsPkgFile << std::endl;
        return false;
    }

    if(getenv("INCLUDE_TCL_PKG") != NULL)
    {
        char *pLine = NULL;
        size_t len = 0;
        while(getline(&pLine, &len, pTrsPkg) != -1)
        {
            trspkg += pLine;
        }
        if(pLine != NULL)
            ::free(pLine);
        fclose(pTrsPkg);
        out << trspkg;
    }
    else
    {
        std::string outfile = rcsManager_T::getInstance()->getPVRSOutFile();
        int npos = outfile.find_last_of("/");

        std::string outpath = ".";
        if(npos != std::string::npos)
        {
            outpath = outfile.substr(0,npos);
        }


        std::string cmd = "cp ";
        cmd += pTrsPkgFile;
        cmd += " " + outpath;
        cmd += " > /dev/null";
        if(system(cmd.c_str()) == 0)
        {
            out << "#!trs\n";
            out << "source ./enc_all.tcl";
        }
        else
        {
            s_errManager.addError(rcErrorNode_T(rcErrorNode_T::FATAL, OPEN1, 0, pTrsPkgFile), errout);
            s_errManager.Report(errout);
            return false;
        }
    }
    return true;
}
