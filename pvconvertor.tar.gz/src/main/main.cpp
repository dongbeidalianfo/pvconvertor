#include <cstdlib>
#include <stdlib.h>
#include <string>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <iostream>
#include <fstream>

#include "public/synnode/rcsSynRootNode.h"
#include "public/manager/rcErrorManager.h"
#include "public/manager/rcsManager.h"
#include "preprocess/rcsPreprocessor.h"
#include "preprocess/rcsCheckTextExtractor.h"
#include "lexical/rcsLexParser.h"
#include "lexical/rcsMacroParser.h"
#include "syntax/rcsSynConvertor.h"
#include "tvf/rcsTvfCompiler.h"
#include "rcsSvrf2Pvrs.h"
#include "gui/convertorWin.h"

void PrintLicense()
{
	std::string strLicense = "\n\
************************************************************************************** \n\
***                              SVRF2PVRS LICENSE                                **** \n\
************************************************************************************** \n\
\n\
Redistribution and use in source and binary forms, with or without \n\
modification, are permitted provided that the following conditions are met: \n\
\n\
Redistributions of source code must retain the above copyright notice, this \n\
list of conditions and the following disclaimer. \n\
\n\
Redistributions in binary form must reproduce the above copyright notice, \n\
this list of conditions and the following disclaimer in the documentation \n\
and/or other materials provided with the distribution. \n\
\n\
Neither the name of the copyright holder nor the names of its \n\
contributors may be used to endorse or promote products derived from \n\
this software without specific prior written permission. \n\
\n\
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS \"AS IS\" \n\
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE \n\
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE \n\
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE \n\
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR \n\
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF \n\
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS \n\
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN \n\
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) \n\
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE \n\
POSSIBILITY OF SUCH DAMAGE. \n\
\n\
************************************************************************************** \n\
";
	std::cout << strLicense << endl;
}

void Usage(const char* exeName)
{
    std::cout << "Usage:\n\t" << exeName << " -i source.rule -o[-ol] target.rule [-oc|-full]" << std::endl
			  << std::endl
			  << "Option:\n\n"
			  << "\t" << "-i source.rule" << std::endl
			  << "\t\t" <<" Specify the input SVRF or TVF format rule file." << std::endl
			  << std::endl
              << "\t" << "-o[-ol] target.rule" << std::endl
              << "\t\t" <<" Specify the output target rule file. The default output is PVRS format file." << std::endl
              << "\t\t" <<" The rules of the current switch in the rule file are converted. Only the comment " << std::endl
              << "\t\t" <<" information in the rule check is converted, other comment information is discarded." << std::endl
              << "\t\t" <<" If source.file includes another rule files, the included files will be flattened into target.file." << std::endl
              << "\t\t" <<" If use the “-ol” option, output the rules of in the source.rule to the comments of target.rule." << std::endl
              << std::endl
              << "\t" << "-g[-ggds|-goas] target.rule" << std::endl
              << "\t\t" <<" Specify the output target rule file. The output file contains DRC result definition commands." << std::endl
              << std::endl
              << "\t" << "[-gioas] target.rule" << std::endl
              << "\t\t" <<" Specify the output target rule file. The input and output rule files are both SVRF format files." << std::endl
              << "\t\t" <<" The input rule file is included in the output rule file.The output file contains DRC result definition commands." << std::endl
              << std::endl
              << "\t" << "[-oc]" << std::endl
              << "\t\t" <<" Output the all comments in the source.rule to the target.rule." << std::endl
              << std::endl
  			  << "\t" << "[-full]" << std::endl
  			  << "\t\t" <<" Convert rules that all switch in the source.rule to the target.rule." << std::endl
  			  << "\t\t" <<" By default, the included rule files not be flattened, the all comments are reserved." << std::endl
  			  << "\t\t" <<" If SVRF format in the source.rule, the default output is target.rule file of PVRS format." << std::endl
  			  << "\t\t" <<" If TVF format in the source.rule, the default output is target.rule file of TRS format." << std::endl
  			  << std::endl
              << "\t" << "[-diffrule] diff.rule" << std::endl
              << "\t\t" <<"Specify the output rule file. Specify the SVRF format input rule file "<< std::endl
			  << "\t\t" <<"using -ggds|-goas option if this option is specified" << std::endl
              << std::endl
              << "\t" << "[-v]" << std::endl
              << "\t\t" <<" print time." << std::endl
              << std::endl
              << "\t" << "[-check]" << std::endl
              << "\t\t" <<" Specify the output target rule file." << std::endl
              << "\t\t" <<" Output the all not support commands in the source.rule to the target.rule." << std::endl
              << std::endl;
    exit(0);
}

int main(int argc,char* argv[])
{

    bool outSvrf  			= false;
    bool isGui    			= false;
    bool convertSwitch  	= false;
    bool flattenMacro   	= false;
    bool outComment     	= false;
    bool isNewPvrs      	= true;
    bool expandTmpLayer 	= true;
    bool convertIncludeFile = false;
    bool trsFlag 			= false;
    bool tvfPreprocessFlag 	= false;
    bool printTimeFlag      = false;
    bool isOutputGds        = false;
    bool isOutputOasis      = false;
    bool isDCMInclude		= false;
    std::string sInFile;
    std::string sSwitchFile;
    std::string sOutFile;
    std::string sOutCheckMapFile;		// when -diffrule, sOutCheckMapFile is the input file
    std::string sTmpLayerSuffix;
    std::string sOutDiffFile;
    std::string sOutCheckFile;

    PrintLicense();

    for(int i = 1; i < argc; ++i)
    {
        if(0 == strcasecmp(argv[i],"-i"))
        {
            if(!sInFile.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }

            sInFile = argv[i];
        }
        else if(0 == strcasecmp(argv[i],"-g"))
        {
            if(!sOutCheckMapFile.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }

            sOutCheckMapFile = argv[i];
        }
        else if(0 == strcasecmp(argv[i],"-ggds"))
        {
            if(!sOutCheckMapFile.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }

            sOutCheckMapFile = argv[i];
            isOutputGds = true;
        }
        else if(0 == strcasecmp(argv[i],"-goas") || 0 == strcasecmp(argv[i],"-gioas"))
        {
            if(0 == strcasecmp(argv[i],"-gioas"))
            	isDCMInclude = true;
            if(!sOutCheckMapFile.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }

            sOutCheckMapFile = argv[i];
            isOutputOasis = true;
        }
        else if(0 == strcasecmp(argv[i],"-check"))
        {
            if(!sOutCheckFile.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }

            sOutCheckFile = argv[i];
        }
        else if(0 == strcasecmp(argv[i], "-o"))
        {
            if(!sOutFile.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }

            sOutFile = argv[i];
        }
#if 0
        else if(0 == strcasecmp(argv[i], "-tmp"))
        {
            if(!sTmpLayerSuffix.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }

            sTmpLayerSuffix = argv[i];
        }
#endif
        else if(0 == strcasecmp(argv[i], "-ol"))
        {
            if(!sOutFile.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }
            outSvrf  = true;
            sOutFile = argv[i];
        }
#if 0
        else if(0 == strcasecmp(argv[i], "-oi"))
        {
        	if(!sOutFile.empty() || ++i >= argc)
			{
				Usage(argv[0]);
			}
        	convertIncludeFile = true;
        	convertSwitch = true;
        	sOutFile = argv[i];
        }
#endif
        else if(0 == strcasecmp(argv[i], "-full"))
        {
            if(outComment || convertSwitch)
            {
                Usage(argv[0]);
            }
            convertSwitch = true;

        }
        else if(0 == strcasecmp(argv[i], "-v"))
        {
            if(printTimeFlag)
            {
                Usage(argv[0]);
            }
            printTimeFlag = true;

        }
        else if(0 == strcasecmp(argv[i], "-sf"))
        {
            if(!sSwitchFile.empty() || ++i >= argc || convertSwitch)
            {
                Usage(argv[0]);
            }

            sSwitchFile = argv[i];
        }
        else if(0 == strcasecmp(argv[i], "-oc"))
        {
            if(outComment || convertSwitch)
            {
                Usage(argv[0]);
            }
            outComment = true;
        }
        else if(0 == strcasecmp(argv[i],"-diffrule"))
        {
            if(!sOutDiffFile.empty() || ++i >= argc)
            {
                Usage(argv[0]);
            }
            sOutDiffFile = argv[i];
        }
#if 0
        else if(0 == strcasecmp(argv[i], "-gui"))
        {
            if(isGui)
            {
                Usage(argv[0]);
            }

            isGui = true;
        }
        else if(0 == strcasecmp(argv[i], "-new"))
        {
            if(!isNewPvrs)
            {
                Usage(argv[0]);
            }

            isNewPvrs = true;
        }
        else if(0 == strcasecmp(argv[i], "-old"))
        {
            isNewPvrs = false;
        }
        else if(0 == strcasecmp(argv[i], "-kt"))
        {
            expandTmpLayer = false;
        }
        else if(0 == strcasecmp(argv[i], "-trs"))
        {
        	trsFlag = true;
        }
        else if(0 == strcasecmp(argv[i], "-E"))
		{
        	i+=2;
            if(!sInFile.empty() || !sOutFile.empty() ||  i >= argc)
            {
                Usage(argv[0]);
            }

            sInFile = argv[i];
            sOutFile = argv[--i];
            tvfPreprocessFlag = true;
		}
#endif
    }

    if(printTimeFlag)
    {
        const int YMD = BUILD_DATE / 10000;
        const int YEAR = YMD / 10000;
        const int MONTH = (YMD % 10000) / 100;
        const int DAY = YMD % 100;
        const int TIME = BUILD_DATE % 10000;
        const int HOUR = TIME / 100;
        const int MINUTE = TIME % 100;
        char date[1024];
        sprintf(date, "svrf2pvrs build on %02d/%02d/%d %02d:%02d", MONTH, DAY, YEAR, HOUR, MINUTE);
        std::cout << date << std::endl;
        exit(0);
    }
    if(sOutDiffFile.empty())
    {
        if(false == isGui && (sInFile.empty() || (sOutFile.empty() && sOutCheckMapFile.empty() && sOutCheckFile.empty())))
            Usage(argv[0]);
    }
    else
    {
    	if(false == isGui && (sOutCheckMapFile.empty()))
    		Usage(argv[0]);
    }

    if(!sInFile.empty())
    {
        rcsManager_T::getInstance()->setSourceFile(sInFile);
    }

    if(convertSwitch && !outComment)
    {
        outComment = true;
        convertIncludeFile = true;
    }
    rcsManager_T::getInstance()->setGui(isGui);

    if(tvfPreprocessFlag)
    {
        try
        {
            rcsSvrf2Pvrs convertor;
            convertor.executeTvfPreprocess(sInFile, sOutFile, std::cout);
        }
        catch(const bool &ExitFlag)
        {
            if(!ExitFlag)
                return -1;
        }
    }
    else if(!isGui)
    {
        try
        {
            rcsSvrf2Pvrs convertor;
            rcsSvrf2Pvrs::initUsrPvrsKeyWordSet();
            if(!sOutCheckMapFile.empty())
            {
            	if(sOutDiffFile.empty())
            	{
            		convertor.createDCMRuleFile(sInFile, sOutCheckMapFile, isOutputGds, isOutputOasis, isDCMInclude);
            	}
            	else
            	{
            		//todo..
            	}
            }
            else if (!sOutCheckFile.empty())
            {
                convertor.createCheckRuleFile(sInFile, sOutCheckFile);
            }
            else
            {
                convertor.execute(sInFile, sSwitchFile, sOutFile, outSvrf, convertSwitch,
                                  flattenMacro, outComment, std::cout, isNewPvrs, expandTmpLayer,
                                  convertIncludeFile, trsFlag, sTmpLayerSuffix);
            }
        }
        catch(const bool &ExitFlag)
        {
            if(!ExitFlag)
                return -1;
        }



    }
    else
    {
    	Tk::runGui(argv[0], sInFile.c_str(), (false == sOutFile.empty() ? sOutFile.c_str() : "_temp_rule.pvrs"), outSvrf);
    }

    return 0;
}
