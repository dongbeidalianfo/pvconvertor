#include "rcsSynNodeVisitor.h"
#include "rcsSynCommentNode.h"

rcsSynCommentNode_T::rcsSynCommentNode_T() : m_bAllLine(true)
{
}

const std::string &
rcsSynCommentNode_T::getComment() const
{
    return m_listTokens.front().sValue;
}

void
rcsSynCommentNode_T::accept(rcsNodeVisitor_T &visitor)
{
    visitor.beginVisitCommentNode(this);
    visitor.endVisitCommentNode(this);
}

void
rcsSynCommentNode_T::setAllLine(bool bAllLine)
{
    this->m_bAllLine = bAllLine;
}

bool
rcsSynCommentNode_T::getAllLine()
{
    return this->m_bAllLine;
}
