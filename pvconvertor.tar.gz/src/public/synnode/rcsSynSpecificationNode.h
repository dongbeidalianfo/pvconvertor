



#ifndef SYNSPECIFICATIONNODE_H_
#define SYNSPECIFICATIONNODE_H_


#include "rcsSynNode.h"
#include <list>

class rcsSynSpecificationNode_T: public rcsSynNode_T
{
public:
    rcsSynSpecificationNode_T(KEY_TYPE eKeyType, bool isLocal = false, bool isInMacro = false);

    virtual void accept(rcsNodeVisitor_T &visitor);

    KEY_TYPE getSpecificationType() const;

    bool isLocal() const;

    bool isInMacro() const;

    void setDeviceWithProperty(bool flag);

    bool isDeviceWithProperty() const;

    void setMacroParams(const std::list<std::string>& macroPrams);

    std::list<std::string> getMacroParams() const;

protected:
    KEY_TYPE m_eSpecType;
    bool     m_isLocal;
    bool 	 m_isInMacro;
    bool     m_isDeviceWithProperty;
    std::list<std::string> m_lMacroParams;
};

#endif 
