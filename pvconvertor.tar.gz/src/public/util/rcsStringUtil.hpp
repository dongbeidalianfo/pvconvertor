



#ifndef UTSTRINGUTIL_HPP_
#define UTSTRINGUTIL_HPP_

#include <cctype>
#include <cstddef>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>

#include "public/rcsTypes.h"

inline void
trimBegin(std::string &str, const char *pTrim = " \t\r\n")
{
    std::string::size_type nIndex = str.find_first_not_of(pTrim, 0);
    if(nIndex == std::string::npos)
    {
        str.clear();
    }
    else
    {
        str.erase(0, nIndex);
    }
}

inline void
trimEnd(std::string &str, const char *pTrim = " \t\r\n")
{
    std::string::size_type nIndex = str.find_last_not_of(pTrim);
    if(nIndex != std::string::npos)
    {
        str.erase(nIndex + 1, str.length());
    }
}

inline void
trim(std::string &str, const char *pTrim = " \t\r\n")
{
    trimBegin(str, pTrim);
    trimEnd(str, pTrim);
}

inline void
toUpper(std::string &str)
{
    std::transform(str.begin(), str.end(), str.begin(), ::toupper);
}

inline void
toLower(std::string &str)
{
    std::transform(str.begin(), str.end(), str.begin(), ::tolower);
}

inline int simpliedStrNcaseCmp(const char* s1 , const char* s2, size_t n)
{
    if(0 == n) return 0;
    if(!s1 && !s2) return 0;
    if(!s1 && s2) return -1;
    if(s1 && !s2) return 1;

    while (std::isspace(*s1)) {
        ++s1;
    }
    while (std::isspace(*s2)) {
        ++s2;
    }
    char c1, c2;
    do {
        c1 = *s1++;
        c2 = *s2++;
        if(std::tolower(c1) == std::tolower(c2))
        {
            if(std::isspace(c1))
            {
                while (std::isspace(c1)) {
                    c1 = *s1++;
                }
                while (std::isspace(c2)) {
                    c2 = *s2++;
                }
                --n;
            }
        }
        else {
            break;
        }
    }
    while (--n && s1 && s2);
    return tolower(c1) - tolower(c2);
}

inline std::string
itoa(hvUInt32 num)
{
    char buf[32];
    sprintf(buf,"%u",num);
    return std::string(buf);
}

inline std::string
ftoa(double fValue)
{
    char buf[32];
    sprintf(buf, "%lf", fValue);
    return std::string(buf);
}

hvUInt32 getNumEnvValue(const char *pName, double &fValue);



void _replaceBuildIn(const std::string &sBuildIn, std::string &sResult);

bool _replaceComment(const std::string &sCheckComment, std::string &sResult,
                bool isRuleCheckComment = true, bool isTvfFile = false);

template<class Container>
void tokenize(Container &v, const std::string &str,
                     const char *pToken = " ", const bool addEmpty = false)
{
    if(str.empty())
    {
        return;
    }

    std::string::size_type pre_index = 0, index = 0;
    while((index = str.find_first_of(pToken, pre_index)) != std::string::npos)
    {
        if(index != 0)
        {
            std::string element = str.substr(pre_index, index - pre_index);
            trim(element);
            
            if((!addEmpty && !element.empty()) || addEmpty)
                v.push_back(str.substr(pre_index, index - pre_index));
        }
        pre_index = index + 1;
    }

    std::string element = str.substr(pre_index);
    if((!addEmpty && !element.empty()) || addEmpty)
        v.push_back(element);
}


bool isTclPackageLine(const std::string &line);

inline bool isCoordinateValue(std::string str)
{
	trim(str);
	for(int i = 0; i<str.size(); i++)
	{
		char chTmp = str[i];
		if(!isdigit(chTmp))
		{
			if((chTmp != '-') && (chTmp != '+') && !isspace(chTmp)
			&& (chTmp != '(') && (chTmp != ')') && (chTmp != '.'))
			{
				return false;
			}
		}
	}


	return true;

}

#endif 
