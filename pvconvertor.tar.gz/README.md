# PVconverter
---------------------------------------
## Quick Introduction

PVconverter is a language translation tool which can convert the commonly used physical verification programming languages to each other. The applicable PV languages include x SVRF, PVS, PVRS, etc.

The widely used physical verification tools include calibre, Argus, PVS which all have the mature function of DRC (Design Rule Check), LVS (Layout Versus Schematic) check, ERC (Electrical Rule Check). The PVconverter is developed for helping the designer to transfer the PV rule-deck among the commonly used PV languages. With the help of the converter, the users will do the verification work smoothly.

This guide contains information about the PVconverter Commands and is intended for developers who need transfer the calibre physical verification rules to Argus/PVS format. This guide does not include information about installing the PVconverter tool.

## Building requirements (Linux)
You need install the following reqirements:
- flex
- yacc

Download the requirements and place them under `tools` directory.
- tcl

Download the requirements and place them under `share` directory.

## Building instructions (Linux)

Execute `make install`, and you'll get the executable file under `platform` directory.


## Usage

### Syntax1:
`svrf2pvrs -i svrf_rule -o pvrs_rule`
### Syntax2:
`svrf2pvs -i svrf_rule -o pvs_rule`
### Option:

- `[-i svrf_rule_file]`: Specify A required input SVRF ruledeck.

- `[-sf switch_file]`: Specify the input switches in this file. Switch file format: #define METAL5

- `[-full]`: This option instructs converter to transfer all switches in the ruledeck. This option is not recommended because converter may fail to convertor the ruledeck for some situations which you can find in the readme.txt in the converter package. If not use this option, converter only convert the active switches to pvrs ruledeck.

- `[-oc]`: Output the comments in the ruledeck to PVRS ruledeck.

- `[-o[l] pvrs_rule_file|pvs_rule_file]`: Specify the output PVRS ruledeck. If use the "-ol" option, svrf2pvrs will output the SVRF rules to the comments of PVRS ruledeck.

- `[-trs]`: instructs the convertor convert a TVF rule deck into a TRS rule deck

- `[-gui]`: Use GUI to setup and run convertor. As Fig.1

![](file:///images/fig1.png)
Fig.1 PVconverter Graphical User Interface

### Description:

Converts the Physical-Verification ruledeck among different programming language.

Convertor can't convert non-SVRF statement.

There are many switches(#define) in a rule deck, convertor only convert effective path and delete non effective switches and paths by default. If a use changes the switches in SVRS rule deck, PVRS/PVS rue deck should be converted again. [-full] instructs the convertor convert all switches and paths at the same time. In default mode, PVconvertor could transfer all rules which it supports. But in full mode, some special structures could not be transferred without the help of users.

### Error Reporting

- PVconvertor can't convert non-SVRF statement. If there are non-SVRF statement it will be report "svrf error".
- If "#IFDEF" or "#ENDIF" is written in comments, PVconvertor will report an error.

If there are unsupported SVRF statements, convertor will report a warning and ignore them.

Unsupported statements include DRC run-time TVF, PERC, PEX, RET, ICTRACE, MASK and OPC (OPC BIAS is supported)

- PVconvertor only supports 7 DFM rules. They are: DFM COPY, DFM NARAC, DFM PROPERTY, DFM RDB, DFM STAMP, DFM SPACE, DFM SIZE

- PVconvertor could not convert a complete SVRF statement if it is separated by "#ifdef#else#endif". A statement should be completed in each branch. For example. DMACRO defined the property of the devices. It is a part of device statements.The device statement is not complete.

```c
DMACRO mim_prop seed_layer area_c perimeter_c {
[
  PROPERTY C
  A = area(seed_layer)
  P = perimeter(seed_layer)
  C = A*area_c + P*fringe_c
] }

#IFDEF METAL4

DEVICE C(MIM) MiM_C MiM_C(POS) M4(NEG)

#ENDIF


#IFDEF METAL5

DEVICE C(MIM) MiM_C MiM_C(POS) M5(NEG)

#ENDIF

CMACRO mim_prop MiM_C 1.1e-3 1.2e-9
```

PVconverter need complete the statement in each branch like this:
```c
#IFDEF METAL4

DEVICE C(MIM) MiM_C MiM_C(POS) M4(NEG)

CMACRO mim_prop MiM_C 1.1e-3 1.2e-9

#ENDIF


#IFDEF METAL5

DEVICE C(MIM) MiM_C MiM_C(POS) M5(NEG)

CMACRO mim_prop MiM_C 1.1e-3 1.2e-9

#ENDIF
```

- If a macro is not a complete statement, it could not be defined in many branches. For example: In this case, the macro mim_prop is a part of a device statement and defined in the two branches. PVconvertor will complete the non-complete statement before convert it to PVRS. So an error of duplicate definitions will be reported.
```c
#IFDEF PROPERTY_C

DMACRO mim_prop seed_layer {
[
  PROPERTY C
  A = area(seed_layer)
  P = perimeter(seed_layer)
  C = A*1.1e-3 + P*1.2e-9
]}

#ELSE

DMACRO mim_prop seed_layer {
[
  PROPERTY A P
  A = area(seed_layer)
  P = perimeter(seed_layer)
]}

#ENDIF

DEVICE C(MIM) MiM_C MiM_C(POS) M5(NEG)

CMACRO mim_prop MiM_C

```

Because the macro name is duplicate, PVconverter need to change the names of the macros and make a branch for the device calling the macro like:
```c
DMACRO mim_prop_c seed_layer {
[
  PROPERTY C
  A = area(seed_layer)
  P = perimeter(seed_layer)
  C = A*1.1e-3 + P*1.2e-9
]}

DMACRO mim_prop_ap seed_layer {
[
  PROPERTY A P
  A = area(seed_layer)
  P = perimeter(seed_layer)
]}

#IFDEF PROPERTY_C

DEVICE C(MIM) MiM_C MiM_C(POS) M5(NEG)

CMACRO mim_prop_c MiM_C

#ELSE

DEVICE C(MIM) MiM_C MiM_C(POS) M5(NEG)

CMACRO mim_prop_ap MiM_C

#ENDIF
```

- If tvf rule file contains the usage of consecutive svrf layer operation keywords more than once, convertor may fail. By default, PVconvertor generates one temporary layer definition for every layer operation command to avoid this case.
- For unsupported TVF rules, PVconvertor reports warning and skip them.
